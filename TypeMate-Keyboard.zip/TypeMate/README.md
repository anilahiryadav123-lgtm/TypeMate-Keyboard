# TypeMate Keyboard ⌨️

Asli Android keyboard (Input Method / IME) – WhatsApp, Instagram, Chrome, Messages sab apps me kaam karta hai.

## Features
- Mobile QWERTY layout + number row, Shift / Caps lock, Backspace (hold = fast delete), Emoji, Space, Comma, Full stop, Enter
- Languages: **English, Hindi (हिन्दी), Marathi (मराठी), Bhojpuri (भोजपुरी)** – 🌐 key se switch
- **109 themes** ka Theme Store – live preview + Apply (Light, Dark, Gradient, Colorful)
- Toolbar: Menu, Emoji, Clipboard, Translate, GIF, Stickers, Theme, Text editing, Settings, Mic
- Word suggestions, auto-correction (backspace = undo), auto-capital, double-space full stop
- Glide typing (English), space bar par slide = cursor move
- Long press = special characters (é, ñ, ₹, क्ष, ज्ञ, त्र …)
- Voice typing (English / Hindi / Marathi)
- Clipboard history, Emoji keyboard (recent emojis), 28 offline Stickers, GIF search (GIPHY key)
- One-handed mode, keyboard height, key text size, bold keys, key borders, sound & vibration
- Gboard jaisa Settings page: Languages, Preferences, Theme, Corrections & suggestions, Glide typing,
  Voice typing, Clipboard, Dictionary, Emojis Stickers & GIFs, Share, Privacy, Rate us, About, Help & feedback

## APK kaise banaye (GitHub se, mobile par)
1. GitHub par naya repository banao, naam: `TypeMate`
2. ZIP extract karke saari files/folders upload karo (`app`, `build.gradle`, `settings.gradle`, `gradle.properties`)
3. `.github` folder phone se upload nahi hota, isliye:
   **Add file → Create new file** → naam likho `.github/workflows/build.yml` → `build.yml` ka content paste karo → Commit
4. **Actions** tab → "Build TypeMate APK" chalega (5–8 minute)
5. Green ✅ hone par run kholo → neeche **Artifacts → TypeMate-Keyboard-APK** download karo → unzip → APK install

## Phone par chalu karna
1. TypeMate app kholo → **1. Enable TypeMate** → switch ON
2. **2. Select TypeMate** → TypeMate Keyboard choose karo
3. **3. Allow microphone** (voice typing ke liye)
