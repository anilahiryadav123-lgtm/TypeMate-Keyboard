package com.typemate.keyboard;

import android.graphics.Color;

public class KeyboardTheme {
    public static final String LIGHT = "Light";
    public static final String DARK = "Dark";
    public static final String GRADIENT = "Gradient";
    public static final String COLORFUL = "Colorful";

    public String id, name, category;
    public int bgTop, bgBottom;
    public int key, keyText;
    public int func, funcText;
    public int action, actionText;
    public int numKey, numText;
    public int toolbar, toolbarIcon;
    public int accent;
    public int border;
    public int popupBg, popupText;
    public float radius = 8f;
    public boolean shadow = true;

    public KeyboardTheme(String id, String name, String category) {
        this.id = id;
        this.name = name;
        this.category = category;
    }

    /** Fills derived colors that were not given. */
    public KeyboardTheme finish() {
        if (numKey == 0) { numKey = key; numText = keyText; }
        if (numText == 0) numText = onColor(numKey);
        if (popupBg == 0) {
            popupBg = Color.alpha(key) < 250 ? (lum(bgTop) > 0.5 ? 0xFFFFFFFF : 0xFF2B2B2B) : key;
        }
        if (popupText == 0) popupText = Color.alpha(key) < 250 ? onColor(popupBg) : keyText;
        return this;
    }

    public boolean isDark() {
        return lum(mix(bgTop, bgBottom, 0.5f)) < 0.45;
    }

    // ---- color helpers ----
    public static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        int al = (int) (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t);
        return Color.argb(al, r, g, bl);
    }

    public static double lum(int c) {
        return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
    }

    public static int onColor(int c) {
        return lum(c) > 0.6 ? 0xFF1F1F1F : 0xFFFFFFFF;
    }

    public static int withAlpha(int c, int alpha) {
        return Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c));
    }
}
