package com.typemate.keyboard;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputContentInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The TypeMate input method (the real Android keyboard). */
public class TypeMateIME extends InputMethodService
        implements KeyboardView.Listener, SharedPreferences.OnSharedPreferenceChangeListener {

    private SharedPreferences sp;
    private boolean dirty = true;
    private Dictionary dict;
    private KeyboardTheme theme;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newFixedThreadPool(3);

    // views
    private FrameLayout root;
    private LinearLayout strip;
    private ImageView menuBtn, micBtn;
    private HorizontalScrollView toolbarScroll;
    private LinearLayout suggestionRow;
    private TextView statusText;
    private final TextView[] sugViews = new TextView[3];
    private final String[] sugWords = new String[3];
    private FrameLayout panelHost;
    private LinearLayout keyboardHolder;
    private KeyboardView kv;
    private PreviewOverlay overlay;
    private String panel = "keys";
    private int stripText;
    private int panelText;

    // state
    private List<String> langs;
    private int langIndex;
    private int page = Layouts.PAGE_LETTERS;
    private int shiftState;
    private long lastShiftTime;
    private final StringBuilder composing = new StringBuilder();
    private boolean predictionOn, autoCorrectOn, learnOn, isPassword;
    private String corrOriginal, corrResult;
    private boolean justPicked;
    private long lastSpaceTime;
    private String lastGlide;
    private List<String> glideAlts;
    private boolean textEditSelect;

    // services
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private SpeechRecognizer recognizer;
    private boolean listening;
    private AudioManager audio;
    private Vibrator vibrator;

    // ================================================================ lifecycle

    @Override public void onCreate() {
        super.onCreate();
        sp = Prefs.sp(this);
        sp.registerOnSharedPreferenceChangeListener(this);
        dict = new Dictionary(this);
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipListener = () -> {
            try {
                if (!Prefs.b(this, Prefs.CLIPBOARD)) return;
                ClipData cd = clipboard.getPrimaryClip();
                if (cd != null && cd.getItemCount() > 0) {
                    CharSequence t = cd.getItemAt(0).coerceToText(this);
                    if (t != null) ClipHistory.add(this, t.toString());
                }
            } catch (Exception ignored) {
            }
        };
        if (clipboard != null) clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override public void onDestroy() {
        sp.unregisterOnSharedPreferenceChangeListener(this);
        if (clipboard != null) clipboard.removePrimaryClipChangedListener(clipListener);
        stopVoice();
        exec.shutdownNow();
        super.onDestroy();
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences s, String key) {
        dirty = true;
    }

    @Override public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override public View onCreateInputView() {
        return buildView();
    }

    @Override public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (dirty || root == null) setInputView(buildView());
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        isPassword = (cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))
                || (cls == InputType.TYPE_CLASS_NUMBER && var == InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        boolean special = cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_URI || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_FILTER);
        predictionOn = Prefs.b(this, Prefs.SUGGEST) && cls == InputType.TYPE_CLASS_TEXT && !isPassword;
        autoCorrectOn = predictionOn && Prefs.b(this, Prefs.AUTOCORRECT) && !special;
        learnOn = Prefs.b(this, Prefs.LEARN) && !isPassword
                && (info.imeOptions & EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) == 0;
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME) {
            page = Layouts.PAGE_PHONE;
        } else {
            page = Layouts.PAGE_LETTERS;
        }
        composing.setLength(0);
        corrOriginal = corrResult = null;
        justPicked = false;
        lastGlide = null;
        glideAlts = null;
        shiftState = 0;
        showPanel("keys");
        loadLayout();
        updateEnterKey(info);
        updateShiftAuto();
        refreshSuggestions();
    }

    @Override public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        stopVoice();
        if (kv != null) kv.cancelTouch();
    }

    @Override public void onFinishInput() {
        super.onFinishInput();
        composing.setLength(0);
    }

    @Override public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                            int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        if (composing.length() > 0 && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            composing.setLength(0);
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.finishComposingText();
            refreshSuggestions();
        }
        if (composing.length() == 0) updateShiftAuto();
    }

    // ================================================================ view building

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private View buildView() {
        dirty = false;
        theme = ThemeRegistry.get(Prefs.s(this, Prefs.THEME));
        langs = Prefs.langs(this);
        langIndex = Math.min(Prefs.i(this, Prefs.LANG_INDEX), langs.size() - 1);
        int mid = KeyboardTheme.mix(theme.bgTop, theme.bgBottom, 0.5f);
        stripText = theme.toolbar == 0 ? KeyboardTheme.onColor(mid) : theme.toolbarIcon;
        panelText = KeyboardTheme.onColor(mid);

        root = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{theme.bgTop, theme.bgBottom});
        root.setBackground(bg);

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(column, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        // ---- top strip
        strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        if (theme.toolbar != 0) strip.setBackgroundColor(theme.toolbar);
        column.addView(strip, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        menuBtn = iconButton(R.drawable.ic_grid, theme.toolbarIcon);
        menuBtn.setOnClickListener(v -> {
            feedback(null);
            showPanel("keys".equals(panel) ? "menu" : "keys");
        });
        strip.addView(menuBtn, new LinearLayout.LayoutParams(dp(48), dp(48)));

        FrameLayout content = new FrameLayout(this);
        strip.addView(content, new LinearLayout.LayoutParams(0, dp(48), 1f));

        toolbarScroll = new HorizontalScrollView(this);
        toolbarScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        toolbarScroll.addView(tools);
        toolbarScroll.setFillViewport(true);
        addTool(tools, R.drawable.ic_clipboard, () -> showPanel("clipboard"));
        addTool(tools, R.drawable.ic_translate, () -> showPanel("translate"));
        addTool(tools, R.drawable.ic_settings, () -> openActivity(SettingsActivity.class, null));
        content.addView(toolbarScroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        suggestionRow = new LinearLayout(this);
        suggestionRow.setOrientation(LinearLayout.HORIZONTAL);
        suggestionRow.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            if (i > 0) {
                View div = new View(this);
                div.setBackgroundColor(KeyboardTheme.withAlpha(stripText, 60));
                suggestionRow.addView(div, new LinearLayout.LayoutParams(dp(1), dp(22)));
            }
            TextView t = new TextView(this);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(17);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setTextColor(stripText);
            t.setPadding(dp(4), 0, dp(4), 0);
            final int idx = i;
            t.setOnClickListener(v -> {
                if (sugWords[idx] != null) {
                    feedback(null);
                    pickSuggestion(sugWords[idx]);
                }
            });
            t.setOnLongClickListener(v -> {
                String w = sugWords[idx];
                if (w != null && composing.length() > 0 && w.equalsIgnoreCase(composing.toString())) {
                    dict.learn(w, lang(), 3);
                    Toast.makeText(this, "\"" + w + "\" saved to dictionary", Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            });
            sugViews[i] = t;
            suggestionRow.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        content.addView(suggestionRow, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        statusText = new TextView(this);
        statusText.setGravity(Gravity.CENTER);
        statusText.setTextColor(stripText);
        statusText.setTextSize(15);
        statusText.setSingleLine(true);
        statusText.setEllipsize(TextUtils.TruncateAt.START);
        content.addView(statusText, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        micBtn = iconButton(R.drawable.ic_mic, theme.keyText);
        GradientDrawable micBg = new GradientDrawable();
        micBg.setShape(GradientDrawable.OVAL);
        micBg.setColor(theme.key);
        micBtn.setBackground(micBg);
        micBtn.setOnClickListener(v -> {
            feedback(null);
            if (listening) stopVoice(); else startVoice();
        });
        if (Prefs.b(this, Prefs.VOICE)) {
            LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(42), dp(42));
            mlp.setMargins(dp(2), 0, dp(8), 0);
            strip.addView(micBtn, mlp);
        }

        // ---- keyboard
        overlay = new PreviewOverlay(this);
        overlay.setTheme(theme);
        kv = new KeyboardView(this);
        kv.setTheme(theme);
        kv.setListener(this);
        kv.setOverlay(overlay);
        kv.heightPct = Prefs.i(this, Prefs.HEIGHT);
        kv.textPct = Prefs.i(this, Prefs.TEXT_SIZE);
        kv.bold = Prefs.b(this, Prefs.BOLD);
        kv.keyPopup = Prefs.b(this, Prefs.KEY_POPUP);
        kv.borders = Prefs.b(this, Prefs.KEY_BORDERS);
        kv.longPressMs = Prefs.i(this, Prefs.LONG_DELAY);
        kv.glideTrail = Prefs.b(this, Prefs.GLIDE_TRAIL);

        keyboardHolder = new LinearLayout(this);
        keyboardHolder.setOrientation(LinearLayout.HORIZONTAL);
        String oneHanded = Prefs.s(this, Prefs.ONE_HANDED);
        if ("0".equals(oneHanded)) {
            keyboardHolder.addView(kv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            LinearLayout side = new LinearLayout(this);
            side.setOrientation(LinearLayout.VERTICAL);
            side.setGravity(Gravity.CENTER);
            ImageView expand = iconButton(R.drawable.ic_expand, panelText);
            expand.setOnClickListener(v -> {
                sp.edit().putString(Prefs.ONE_HANDED, "0").apply();
                setInputView(buildView());
            });
            final boolean left = "1".equals(oneHanded);
            ImageView move = iconButton(left ? R.drawable.ic_right : R.drawable.ic_left, panelText);
            move.setOnClickListener(v -> {
                sp.edit().putString(Prefs.ONE_HANDED, left ? "2" : "1").apply();
                setInputView(buildView());
            });
            side.addView(expand, new LinearLayout.LayoutParams(dp(44), dp(52)));
            side.addView(move, new LinearLayout.LayoutParams(dp(44), dp(52)));
            LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.84f);
            LinearLayout.LayoutParams spp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.16f);
            if (left) {
                keyboardHolder.addView(kv, kp);
                keyboardHolder.addView(side, spp);
            } else {
                keyboardHolder.addView(side, spp);
                keyboardHolder.addView(kv, kp);
            }
        }

        panelHost = new FrameLayout(this);
        column.addView(panelHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel = "";
        root.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        showPanel("keys");
        loadLayout();
        updateEnterKey(getCurrentInputEditorInfo());
        return root;
    }

    private ImageView iconButton(int res, int tint) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setColorFilter(tint);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        android.util.TypedValue tv = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true);
        iv.setBackgroundResource(tv.resourceId);
        return iv;
    }

    private void addTool(LinearLayout tools, int res, Runnable r) {
        ImageView iv = iconButton(res, theme.toolbarIcon);
        iv.setOnClickListener(v -> {
            feedback(null);
            r.run();
        });
        tools.addView(iv, new LinearLayout.LayoutParams(0, dp(48), 1f));
    }

    private String lang() {
        if (langs == null || langs.isEmpty()) return "en";
        return langs.get(Math.max(0, Math.min(langIndex, langs.size() - 1)));
    }

    private boolean isEnglish() {
        return "en".equals(lang());
    }

    private void loadLayout() {
        if (kv == null) return;
        boolean letters = page == Layouts.PAGE_LETTERS || page == Layouts.PAGE_SHIFT;
        kv.phonePad = page == Layouts.PAGE_PHONE;
        kv.targetRows = Prefs.b(this, Prefs.NUMBER_ROW) ? 5 : 4;
        kv.caseSensitive = isEnglish() && letters;
        kv.glideEnabled = Prefs.b(this, Prefs.GLIDE) && isEnglish() && page == Layouts.PAGE_LETTERS && predictionOn;
        kv.spaceLabel = Prefs.langName(lang());
        kv.setRows(Layouts.build(lang(), page, Prefs.b(this, Prefs.NUMBER_ROW), false, Prefs.b(this, Prefs.EMOJI_KEY)));
        kv.setShift(isEnglish() ? shiftState : (page == Layouts.PAGE_SHIFT ? 1 : 0));
    }

    private void updateEnterKey(EditorInfo info) {
        if (kv == null || info == null) return;
        int action = info.imeOptions & EditorInfo.IME_MASK_ACTION;
        boolean noAction = (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
        int icon = R.drawable.ic_enter;
        if (!noAction) {
            switch (action) {
                case EditorInfo.IME_ACTION_SEARCH: icon = R.drawable.ic_search; break;
                case EditorInfo.IME_ACTION_SEND: icon = R.drawable.ic_send; break;
                case EditorInfo.IME_ACTION_GO:
                case EditorInfo.IME_ACTION_NEXT: icon = R.drawable.ic_next; break;
                case EditorInfo.IME_ACTION_DONE: icon = R.drawable.ic_done; break;
                default: icon = R.drawable.ic_enter;
            }
        }
        kv.enterIcon = icon;
        kv.invalidate();
    }

    // ================================================================ panels

    private void showPanel(String name) {
        if (panelHost == null) return;
        if (name.equals(panel)) return;
        if (!"keys".equals(name) && composing.length() > 0) commitComposing(false);
        panel = name;
        panelHost.removeAllViews();
        if (overlay != null) overlay.clear();
        menuBtn.setImageResource("keys".equals(name) ? R.drawable.ic_grid : R.drawable.ic_close);
        if ("keys".equals(name)) {
            panelHost.addView(keyboardHolder);
            refreshSuggestions();
            return;
        }
        int h = KeyboardView.panelHeight(this, Prefs.i(this, Prefs.HEIGHT), Prefs.b(this, Prefs.NUMBER_ROW));
        View v;
        switch (name) {
            case "menu": v = buildMenuPanel(); break;
            case "emoji": v = buildEmojiPanel(); break;
            case "clipboard": v = buildClipboardPanel(); break;
            case "gif": v = buildGifPanel(); break;
            case "sticker": v = buildStickerPanel(); break;
            case "textedit": v = buildTextEditPanel(); break;
            case "translate": v = buildTranslatePanel(); break;
            case "resize": v = buildResizePanel(); break;
            default: v = new View(this);
        }
        panelHost.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        showStatus(panelTitle(name));
    }

    private String panelTitle(String name) {
        switch (name) {
            case "menu": return "TypeMate";
            case "emoji": return "Emoji";
            case "clipboard": return "Clipboard";
            case "gif": return "GIFs";
            case "sticker": return "Stickers";
            case "textedit": return "Text editing";
            case "translate": return "Translate";
            case "resize": return "Keyboard size";
            default: return "";
        }
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView pillButton(String label, int bg, int fg) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(fg);
        t.setTextSize(15);
        t.setBackground(rounded(bg, 22));
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    private View buildMenuPanel() {
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(col);
        Object[][] items = {
                {R.drawable.ic_palette, "Theme", "theme"}, {R.drawable.ic_sticker, "Sticker", "sticker"},
                {R.drawable.ic_gif, "GIF", "gif"}, {R.drawable.ic_emoji, "Emoji", "emoji"},
                {R.drawable.ic_onehand, "One-handed", "onehand"}, {R.drawable.ic_textedit, "Text editing", "textedit"},
                {R.drawable.ic_clipboard, "Clipboard", "clipboard"}, {R.drawable.ic_translate, "Translate", "translate"},
                {R.drawable.ic_height, "Resize", "resize"}, {R.drawable.ic_globe, "Languages", "languages"},
                {R.drawable.ic_mic, "Voice typing", "voice"}, {R.drawable.ic_settings, "Settings", "settings"}
        };
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
            }
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.HORIZONTAL);
            tile.setGravity(Gravity.CENTER_VERTICAL);
            tile.setPadding(dp(16), 0, dp(12), 0);
            tile.setBackground(rounded(theme.key, 28));
            ImageView ic = new ImageView(this);
            ic.setImageResource((Integer) items[i][0]);
            ic.setColorFilter(theme.keyText);
            tile.addView(ic, new LinearLayout.LayoutParams(dp(24), dp(24)));
            TextView tv = new TextView(this);
            tv.setText((String) items[i][1]);
            tv.setTextColor(theme.keyText);
            tv.setTextSize(15);
            tv.setPadding(dp(12), 0, 0, 0);
            tv.setSingleLine(true);
            tile.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final String action = (String) items[i][2];
            tile.setOnClickListener(v -> {
                feedback(null);
                menuAction(action);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            row.addView(tile, lp);
        }
        return sv;
    }

    private void menuAction(String a) {
        switch (a) {
            case "theme": openActivity(ThemeStoreActivity.class, null); break;
            case "onehand":
                String cur = Prefs.s(this, Prefs.ONE_HANDED);
                sp.edit().putString(Prefs.ONE_HANDED, "0".equals(cur) ? "2" : "0").apply();
                setInputView(buildView());
                break;
            case "languages": openActivity(SettingsDetailActivity.class, "languages"); break;
            case "voice": showPanel("keys"); startVoice(); break;
            case "settings": openActivity(SettingsActivity.class, null); break;
            default: showPanel(a);
        }
    }

    private void openActivity(Class<?> cls, String page) {
        Intent i = new Intent(this, cls);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (page != null) i.putExtra("page", page);
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------- emoji
    private View buildEmojiPanel() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(46));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalScrollBarEnabled(false);
        col.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final Map<String, List<String>> cats = EmojiData.load(this);
        final List<String> current = new ArrayList<>();
        final BaseAdapter adapter = new BaseAdapter() {
            @Override public int getCount() { return current.size(); }
            @Override public Object getItem(int p) { return current.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View cv, ViewGroup parent) {
                TextView t = cv instanceof TextView ? (TextView) cv : new TextView(TypeMateIME.this);
                t.setLayoutParams(new android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
                t.setGravity(Gravity.CENTER);
                t.setTextSize(26);
                t.setTextColor(0xFF000000);
                t.setText(current.get(p));
                return t;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            String e = current.get(position);
            feedback(null);
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.commitText(e, 1);
            EmojiData.addRecent(this, e);
        });

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setBackgroundColor(KeyboardTheme.withAlpha(theme.func, Math.max(120, android.graphics.Color.alpha(theme.func))));
        TextView abc = new TextView(this);
        abc.setText("ABC");
        abc.setTextColor(theme.funcText);
        abc.setTypeface(Typeface.DEFAULT_BOLD);
        abc.setGravity(Gravity.CENTER);
        abc.setOnClickListener(v -> showPanel("keys"));
        bottom.addView(abc, new LinearLayout.LayoutParams(dp(56), dp(44)));
        HorizontalScrollView tabsScroll = new HorizontalScrollView(this);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        final LinearLayout tabs = new LinearLayout(this);
        tabsScroll.addView(tabs);
        bottom.addView(tabsScroll, new LinearLayout.LayoutParams(0, dp(44), 1f));
        ImageView del = iconButton(R.drawable.ic_backspace, theme.funcText);
        del.setOnClickListener(v -> {
            feedback(null);
            handleDelete();
        });
        bottom.addView(del, new LinearLayout.LayoutParams(dp(56), dp(44)));
        col.addView(bottom);

        final List<String> tabNames = new ArrayList<>();
        tabNames.add("🕘");
        tabNames.addAll(cats.keySet());
        final List<TextView> tabViews = new ArrayList<>();
        for (final String tn : tabNames) {
            TextView t = new TextView(this);
            t.setText(tn);
            t.setTextSize(20);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                current.clear();
                if ("🕘".equals(tn)) current.addAll(EmojiData.recent(this));
                else current.addAll(cats.get(tn));
                adapter.notifyDataSetChanged();
                grid.setSelection(0);
                for (TextView o : tabViews) o.setBackground(null);
                v.setBackground(rounded(KeyboardTheme.withAlpha(theme.accent, 90), 18));
            });
            tabViews.add(t);
            tabs.addView(t, new LinearLayout.LayoutParams(dp(44), dp(40)));
        }
        List<String> recent = EmojiData.recent(this);
        int start = recent.isEmpty() ? 1 : 0;
        if (tabViews.size() > start) tabViews.get(start).performClick();
        return col;
    }

    // ---------------- clipboard
    private boolean clipEdit;

    private ImageView circleButton(int res, int bg, int fg) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setColorFilter(fg);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(bg);
        iv.setBackground(g);
        return iv;
    }

    private View buildClipboardPanel() {
        final boolean on = Prefs.b(this, Prefs.CLIPBOARD);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(6), dp(10), dp(4));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = circleButton(R.drawable.ic_back, theme.key, theme.keyText);
        back.setOnClickListener(v -> { feedback(null); clipEdit = false; showPanel("keys"); });
        head.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView title = new TextView(this);
        title.setText("Clipboard");
        title.setTextColor(panelText);
        title.setTextSize(21);
        title.setPadding(dp(14), 0, 0, 0);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageView toggle = circleButton(R.drawable.ic_toggle, theme.key, on ? theme.keyText : KeyboardTheme.withAlpha(theme.keyText, 110));
        toggle.setOnClickListener(v -> {
            feedback(null);
            sp.edit().putBoolean(Prefs.CLIPBOARD, !on).apply();
            Toast.makeText(this, on ? "Clipboard history off" : "Clipboard history on", Toast.LENGTH_SHORT).show();
            panel = "";
            showPanel("clipboard");
        });
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(dp(42), dp(42));
        tl.setMargins(0, 0, dp(8), 0);
        head.addView(toggle, tl);
        ImageView edit = circleButton(clipEdit ? R.drawable.ic_done : R.drawable.ic_edit, theme.key, theme.keyText);
        edit.setOnClickListener(v -> {
            feedback(null);
            clipEdit = !clipEdit;
            panel = "";
            showPanel("clipboard");
        });
        head.addView(edit, new LinearLayout.LayoutParams(dp(42), dp(42)));
        col.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        col.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView label = new TextView(this);
        label.setText(clipEdit ? "Tap an item to delete it" : "Recent");
        label.setTextColor(KeyboardTheme.withAlpha(panelText, 160));
        label.setTextSize(14);
        label.setPadding(dp(4), dp(8), 0, dp(4));
        body.addView(label);

        List<String> items = on ? ClipHistory.get(this) : new java.util.ArrayList<String>();
        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(on ? "Copied text will appear here" : "Clipboard history is off. Tap the switch to turn it on.");
            empty.setTextColor(KeyboardTheme.withAlpha(panelText, 170));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(30), dp(16), 0);
            body.addView(empty);
            return col;
        }
        LinearLayout cols = new LinearLayout(this);
        cols.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        cols.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cols.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(cols);
        int i = 0;
        for (final String s : items) {
            TextView t = new TextView(this);
            t.setText(s);
            t.setMaxLines(5);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setTextColor(theme.keyText);
            t.setTextSize(16);
            t.setPadding(dp(16), dp(14), dp(16), dp(14));
            t.setBackground(rounded(theme.key, 14));
            t.setOnClickListener(v -> {
                feedback(null);
                if (clipEdit) {
                    ClipHistory.remove(this, s);
                    panel = "";
                    showPanel("clipboard");
                    return;
                }
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.commitText(s, 1);
            });
            t.setOnLongClickListener(v -> {
                ClipHistory.remove(this, s);
                panel = "";
                showPanel("clipboard");
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            (i++ % 2 == 0 ? left : right).addView(t, lp);
        }
        return col;
    }

    // ---------------- GIF (GIPHY)
    private static final String[] GIF_CATS = {"Trending", "Hi", "Love", "Haha", "Thank you", "Good morning",
            "Good night", "Wow", "Sad", "Party", "Yes", "No", "Dance", "Bollywood", "Cricket", "Happy birthday"};

    private View buildGifPanel() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final String key = Prefs.s(this, Prefs.GIPHY_KEY).trim();
        if (key.isEmpty()) {
            col.setGravity(Gravity.CENTER);
            col.setPadding(dp(24), 0, dp(24), 0);
            TextView t = new TextView(this);
            t.setText("GIF search uses GIPHY.\nAdd your free GIPHY API key once in\nSettings → Emojis, Stickers & GIFs.");
            t.setTextColor(panelText);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(15);
            col.addView(t);
            TextView b = pillButton("Open GIF settings", theme.action, theme.actionText);
            b.setOnClickListener(v -> openActivity(SettingsDetailActivity.class, "emoji"));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(14);
            col.addView(b, lp);
            return col;
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(dp(6), dp(4), dp(6), dp(4));
        hs.addView(chips);
        col.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        final TextView status = new TextView(this);
        status.setTextColor(panelText);
        status.setGravity(Gravity.CENTER);
        final ScrollView sv = new ScrollView(this);
        final LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        sv.addView(grid);
        FrameLayout body = new FrameLayout(this);
        body.addView(sv);
        body.addView(status, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        col.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        for (final String c : GIF_CATS) {
            TextView chip = pillButton(c, theme.key, theme.keyText);
            chip.setTextSize(13);
            chip.setPadding(dp(12), dp(4), dp(12), dp(4));
            chip.setOnClickListener(v -> loadGifs(key, c, grid, status, sv));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dp(3), 0, dp(3), 0);
            chips.addView(chip, lp);
        }
        loadGifs(key, "Trending", grid, status, sv);
        return col;
    }

    private void loadGifs(final String key, final String query, final LinearLayout grid, final TextView status, final ScrollView sv) {
        status.setVisibility(View.VISIBLE);
        status.setText("Loading…");
        grid.removeAllViews();
        exec.submit(() -> {
            try {
                String url = "Trending".equals(query)
                        ? "https://api.giphy.com/v1/gifs/trending?limit=30&rating=g&api_key=" + URLEncoder.encode(key, "UTF-8")
                        : "https://api.giphy.com/v1/gifs/search?limit=30&rating=g&lang=en&api_key=" + URLEncoder.encode(key, "UTF-8")
                        + "&q=" + URLEncoder.encode(query, "UTF-8");
                JSONArray data = new JSONObject(httpGet(url)).getJSONArray("data");
                final List<String[]> items = new ArrayList<>();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject o = data.getJSONObject(i);
                    JSONObject imgs = o.getJSONObject("images");
                    JSONObject still = imgs.optJSONObject("fixed_width_small_still");
                    if (still == null) still = imgs.optJSONObject("fixed_width_still");
                    JSONObject gif = imgs.optJSONObject("fixed_width");
                    if (still == null || gif == null) continue;
                    items.add(new String[]{o.optString("id", "g" + i), still.getString("url"), gif.getString("url")});
                }
                main.post(() -> showGifGrid(items, grid, status));
            } catch (Exception e) {
                main.post(() -> status.setText("Could not load GIFs. Check internet and API key."));
            }
        });
    }

    private void showGifGrid(List<String[]> items, LinearLayout grid, TextView status) {
        if (items.isEmpty()) {
            status.setText("No GIFs found");
            return;
        }
        status.setVisibility(View.GONE);
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                grid.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(96)));
            }
            final String[] it = items.get(i);
            final ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(rounded(KeyboardTheme.withAlpha(theme.key, 120), 8));
            iv.setClipToOutline(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(iv, lp);
            exec.submit(() -> {
                try (InputStream in = new URL(it[1]).openStream()) {
                    final Bitmap b = BitmapFactory.decodeStream(in);
                    main.post(() -> iv.setImageBitmap(b));
                } catch (Exception ignored) {
                }
            });
            iv.setOnClickListener(v -> {
                feedback(null);
                Toast.makeText(this, "Sending GIF…", Toast.LENGTH_SHORT).show();
                exec.submit(() -> {
                    try {
                        File f = new File(StickerProvider.dir(this), "gif_" + it[0].replaceAll("[^A-Za-z0-9]", "") + ".gif");
                        if (!f.exists()) download(it[2], f);
                        main.post(() -> sendImage(f, "image/gif", "GIF"));
                    } catch (Exception e) {
                        main.post(() -> Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show());
                    }
                });
            });
        }
    }

    // ---------------- stickers
    private View buildStickerPanel() {
        ScrollView sv = new ScrollView(this);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(6), dp(4), dp(6), dp(4));
        sv.addView(grid);
        int size = dp(80);
        LinearLayout row = null;
        for (int i = 0; i < StickerMaker.STICKERS.length; i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(this);
                grid.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(86)));
            }
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(StickerMaker.render(i, size));
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            final int idx = i;
            iv.setOnClickListener(v -> {
                feedback(null);
                exec.submit(() -> {
                    try {
                        File f = StickerMaker.save(this, idx);
                        main.post(() -> sendImage(f, "image/png", "Sticker"));
                    } catch (Exception e) {
                        main.post(() -> Toast.makeText(this, "Sticker failed", Toast.LENGTH_SHORT).show());
                    }
                });
            });
            row.addView(iv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        return sv;
    }

    private void sendImage(File f, String mime, String desc) {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        Uri uri = StickerProvider.uriFor(f);
        boolean supported = false;
        if (ei != null && ei.contentMimeTypes != null) {
            for (String t : ei.contentMimeTypes) {
                if (ClipDescription.compareMimeTypes(mime, t)) { supported = true; break; }
            }
        }
        if (supported && ic != null) {
            InputContentInfo info = new InputContentInfo(uri, new ClipDescription(desc, new String[]{mime}), null);
            if (ic.commitContent(info, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) return;
        }
        try {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(mime);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.setClipData(ClipData.newRawUri(desc, uri));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(share, "Send " + desc);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
            Toast.makeText(this, "This app doesn't accept " + desc + " from keyboards. Choose a chat to send.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Cannot send " + desc + " here", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------- text editing
    private View buildTextEditPanel() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(6), dp(8), dp(6));
        String[][] grid = {
                {"◀", "▲", "▼", "▶"},
                {textEditSelect ? "Select: ON" : "Select", "Select all", "Copy", "Cut"},
                {"Paste", "Start", "End", "⌫"},
        };
        for (String[] r : grid) {
            LinearLayout row = new LinearLayout(this);
            col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            for (final String label : r) {
                boolean on = label.startsWith("Select: ON");
                TextView b = pillButton(label, on ? theme.accent : theme.key, on ? KeyboardTheme.onColor(theme.accent) : theme.keyText);
                b.setTextSize(label.length() <= 2 ? 22 : 15);
                b.setOnClickListener(v -> {
                    feedback(null);
                    textEdit(label);
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                row.addView(b, lp);
            }
        }
        return col;
    }

    private void textEdit(String label) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        switch (label) {
            case "◀": sendKey(KeyEvent.KEYCODE_DPAD_LEFT, textEditSelect); break;
            case "▶": sendKey(KeyEvent.KEYCODE_DPAD_RIGHT, textEditSelect); break;
            case "▲": sendKey(KeyEvent.KEYCODE_DPAD_UP, textEditSelect); break;
            case "▼": sendKey(KeyEvent.KEYCODE_DPAD_DOWN, textEditSelect); break;
            case "Start": sendKey(KeyEvent.KEYCODE_MOVE_HOME, textEditSelect); break;
            case "End": sendKey(KeyEvent.KEYCODE_MOVE_END, textEditSelect); break;
            case "Select all": ic.performContextMenuAction(android.R.id.selectAll); break;
            case "Copy": ic.performContextMenuAction(android.R.id.copy); break;
            case "Cut": ic.performContextMenuAction(android.R.id.cut); break;
            case "Paste": ic.performContextMenuAction(android.R.id.paste); break;
            case "⌫": handleDelete(); break;
            default:
                textEditSelect = !textEditSelect;
                panel = "";
                showPanel("textedit");
        }
    }

    private void sendKey(int code, boolean shift) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        long t = SystemClock.uptimeMillis();
        int meta = shift ? (KeyEvent.META_SHIFT_ON | KeyEvent.META_SHIFT_LEFT_ON) : 0;
        ic.sendKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta));
        ic.sendKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta));
    }

    // ---------------- translate
    private View buildTranslatePanel() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView info = new TextView(this);
        info.setText("Type your message, then choose a language.\nThe text in the box will be translated.");
        info.setTextColor(panelText);
        info.setGravity(Gravity.CENTER);
        col.addView(info);
        final TextView status = new TextView(this);
        status.setTextColor(panelText);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(10), 0, dp(10));
        String[][] targets = {{"English", "en"}, {"हिन्दी", "hi"}, {"मराठी", "mr"}, {"भोजपुरी", "bho"}};
        LinearLayout row = new LinearLayout(this);
        for (final String[] t : targets) {
            TextView b = pillButton(t[0], theme.key, theme.keyText);
            b.setOnClickListener(v -> translateField(t[1], status));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(dp(4), dp(14), dp(4), 0);
            row.addView(b, lp);
        }
        col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(status);
        TextView app = pillButton("Open in Google Translate", theme.action, theme.actionText);
        app.setOnClickListener(v -> openTranslateApp());
        col.addView(app);
        return col;
    }

    private String fieldText() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "";
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        if (et != null && et.text != null) return et.text.toString();
        CharSequence b = ic.getTextBeforeCursor(2000, 0);
        return b == null ? "" : b.toString();
    }

    private void translateField(final String target, final TextView status) {
        final String text = fieldText();
        if (text.trim().isEmpty()) {
            status.setText("Type something first");
            return;
        }
        status.setText("Translating…");
        exec.submit(() -> {
            try {
                String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + target
                        + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8");
                JSONArray parts = new JSONArray(httpGet(url)).getJSONArray(0);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) {
                    JSONArray p = parts.optJSONArray(i);
                    if (p != null && !p.isNull(0)) sb.append(p.getString(0));
                }
                final String result = sb.toString();
                main.post(() -> {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic == null || result.isEmpty()) {
                        status.setText("Translation failed");
                        return;
                    }
                    ic.beginBatchEdit();
                    ic.setSelection(0, text.length());
                    ic.commitText(result, 1);
                    ic.endBatchEdit();
                    status.setText("Translated ✓");
                });
            } catch (Exception e) {
                main.post(() -> status.setText("No internet or translate unavailable"));
            }
        });
    }

    private void openTranslateApp() {
        String text = fieldText();
        try {
            Intent i = new Intent(Intent.ACTION_PROCESS_TEXT);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_PROCESS_TEXT, text);
            i.setPackage("com.google.android.apps.translate");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            try {
                Intent w = new Intent(Intent.ACTION_VIEW, Uri.parse("https://translate.google.com/?sl=auto&tl=hi&text=" + URLEncoder.encode(text, "UTF-8")));
                w.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(w);
            } catch (Exception ignored) {
                Toast.makeText(this, "No translate app found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ---------------- resize
    private View buildResizePanel() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(24), dp(10), dp(24), dp(10));
        final TextView label = new TextView(this);
        label.setTextColor(panelText);
        label.setTextSize(16);
        label.setGravity(Gravity.CENTER);
        final int[] value = {Prefs.i(this, Prefs.HEIGHT)};
        label.setText("Keyboard height: " + value[0] + "%");
        col.addView(label);
        SeekBar sb = new SeekBar(this);
        sb.setMax(70);
        sb.setProgress(value[0] - 70);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                value[0] = 70 + p;
                label.setText("Keyboard height: " + value[0] + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        col.addView(sb, slp);
        LinearLayout row = new LinearLayout(this);
        TextView reset = pillButton("Reset", theme.key, theme.keyText);
        reset.setOnClickListener(v -> {
            sp.edit().putInt(Prefs.HEIGHT, 100).apply();
            setInputView(buildView());
        });
        TextView done = pillButton("Done", theme.action, theme.actionText);
        done.setOnClickListener(v -> {
            sp.edit().putInt(Prefs.HEIGHT, value[0]).apply();
            setInputView(buildView());
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(6), dp(16), dp(6), 0);
        row.addView(reset, lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp2.setMargins(dp(6), dp(16), dp(6), 0);
        row.addView(done, lp2);
        col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return col;
    }

    // ================================================================ strip

    private void showToolbar() {
        if (toolbarScroll == null) return;
        toolbarScroll.setVisibility(View.VISIBLE);
        suggestionRow.setVisibility(View.GONE);
        statusText.setVisibility(View.GONE);
    }

    private void showStatus(String s) {
        if (statusText == null) return;
        statusText.setText(s);
        statusText.setVisibility(View.VISIBLE);
        toolbarScroll.setVisibility(View.GONE);
        suggestionRow.setVisibility(View.GONE);
    }

    private void showSuggestions(List<String> words, int boldIndex) {
        if (suggestionRow == null) return;
        toolbarScroll.setVisibility(View.GONE);
        statusText.setVisibility(View.GONE);
        suggestionRow.setVisibility(View.VISIBLE);
        for (int i = 0; i < 3; i++) {
            String w = i < words.size() ? words.get(i) : null;
            sugWords[i] = w;
            sugViews[i].setText(w == null ? "" : w);
            sugViews[i].setTypeface(i == boldIndex ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }

    private void refreshSuggestions() {
        if (suggestionRow == null || listening) return;
        if (!"keys".equals(panel)) return;
        if (!predictionOn || page == Layouts.PAGE_PHONE) {
            showToolbar();
            return;
        }
        if (composing.length() == 0) {
            if (glideAlts != null && glideAlts.size() > 1) {
                showSuggestions(glideAlts, 0);
                return;
            }
            InputConnection ic = getCurrentInputConnection();
            CharSequence before = ic == null ? null : ic.getTextBeforeCursor(1, 0);
            if (before == null || before.length() == 0 || !justPicked && before.charAt(0) != ' ') {
                showToolbar();
                return;
            }
            List<String> st = dict.starters(lang());
            showSuggestions(st, 1);
            return;
        }
        String typed = composing.toString();
        List<String> out = new ArrayList<>();
        int bold = -1;
        String corr = autoCorrectOn ? dict.correction(typed, lang()) : null;
        boolean known = dict.isKnown(typed, lang());
        List<String> comps = dict.complete(typed, lang(), 4);
        if (corr != null && !corr.equals(typed)) {
            out.add("\"" + typed + "\"");
            out.add(corr);
            bold = 1;
            for (String c : comps) if (out.size() < 3 && !c.equalsIgnoreCase(corr)) out.add(c);
        } else {
            List<String> rest = new ArrayList<>();
            for (String c : comps) if (!c.equalsIgnoreCase(typed)) rest.add(c);
            if (known || rest.isEmpty()) {
                out.add(rest.size() > 0 ? rest.get(0) : "");
                out.add(typed);
                if (rest.size() > 1) out.add(rest.get(1));
                if (out.get(0).isEmpty()) out.set(0, null);
            } else {
                out.add(typed);
                out.add(rest.get(0));
                if (rest.size() > 1) out.add(rest.get(1));
            }
            bold = 1;
        }
        showSuggestions(out, bold);
    }

    private void pickSuggestion(String w) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (w.length() > 2 && w.startsWith("\"") && w.endsWith("\"")) {
            w = w.substring(1, w.length() - 1);
            dict.learn(w, lang(), 2);
        }
        if (glideAlts != null && lastGlide != null && composing.length() == 0) {
            CharSequence b = ic.getTextBeforeCursor(lastGlide.length(), 0);
            if (b != null && b.toString().equals(lastGlide)) ic.deleteSurroundingText(lastGlide.length(), 0);
            String word = Dictionary.applyCase(w, lastGlide);
            ic.commitText(word + " ", 1);
            lastGlide = word + " ";
            glideAlts = null;
            justPicked = true;
            if (learnOn) dict.learn(word, lang(), 1);
            refreshSuggestions();
            return;
        }
        ic.commitText(w + " ", 1);
        composing.setLength(0);
        if (learnOn) dict.learn(w, lang(), 1);
        justPicked = true;
        corrOriginal = corrResult = null;
        glideAlts = null;
        lastGlide = null;
        if (page == Layouts.PAGE_SHIFT) {
            page = Layouts.PAGE_LETTERS;
            loadLayout();
        }
        updateShiftAuto();
        refreshSuggestions();
    }

    // ================================================================ key handling

    @Override public void onKeyDown(Key k) {
        feedback(k);
    }

    private void feedback(Key k) {
        try {
            if (Prefs.b(this, Prefs.VIBRATE)) {
                // Same crisp "keyboard tap" haptic that Gboard uses
                boolean done = false;
                View hv = kv != null ? kv : root;
                if (hv != null) {
                    done = hv.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP,
                            android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                                    | android.view.HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
                }
                if (!done && vibrator != null && vibrator.hasVibrator()) {
                    if (android.os.Build.VERSION.SDK_INT >= 29) {
                        vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK));
                    } else {
                        vibrator.vibrate(VibrationEffect.createOneShot(Math.max(8, Math.min(20, Prefs.i(this, Prefs.VIB_MS))), 120));
                    }
                }
            }
            if (Prefs.b(this, Prefs.SOUND)) {
                int type = KeySound.KEY;
                if (k != null) {
                    if (k.code == Key.DEL) type = KeySound.DEL;
                    else if (k.code == Key.SPACE) type = KeySound.SPACE;
                }
                KeySound.play(type, Prefs.i(this, Prefs.SOUND_VOL) / 100f);
            }
        } catch (Exception ignored) {
        }
    }

    @Override public void onKey(Key k, String text) {
        if (k.code < 0 && k.code != Key.SPACE) {
            handleFunction(k);
            return;
        }
        if (text != null) handleText(text);
    }

    private void handleFunction(Key k) {
        switch (k.code) {
            case Key.SHIFT:
                if (!isEnglish() && (page == Layouts.PAGE_LETTERS || page == Layouts.PAGE_SHIFT)) {
                    page = page == Layouts.PAGE_SHIFT ? Layouts.PAGE_LETTERS : Layouts.PAGE_SHIFT;
                    loadLayout();
                    return;
                }
                long now = SystemClock.uptimeMillis();
                if (shiftState == 0) shiftState = 1;
                else if (shiftState == 1) shiftState = (now - lastShiftTime < 350) ? 2 : 0;
                else shiftState = 0;
                lastShiftTime = now;
                kv.setShift(shiftState);
                break;
            case Key.DEL:
                handleDelete();
                break;
            case Key.ENTER:
                handleEnter();
                break;
            case Key.NUMPAD:
                page = Layouts.PAGE_PHONE;
                loadLayout();
                break;
            case Key.SYM:
                page = Layouts.PAGE_SYM;
                loadLayout();
                break;
            case Key.SYM2:
                page = Layouts.PAGE_SYM2;
                loadLayout();
                break;
            case Key.ABC:
                page = Layouts.PAGE_LETTERS;
                loadLayout();
                updateShiftAuto();
                break;
            case Key.EMOJI:
                showPanel("emoji");
                break;
            case Key.LANG:
                nextLanguage();
                break;
        }
    }

    private void nextLanguage() {
        if (composing.length() > 0) commitComposing(false);
        langIndex = (langIndex + 1) % langs.size();
        sp.unregisterOnSharedPreferenceChangeListener(this);
        sp.edit().putInt(Prefs.LANG_INDEX, langIndex).apply();
        sp.registerOnSharedPreferenceChangeListener(this);
        if (page != Layouts.PAGE_PHONE) page = Layouts.PAGE_LETTERS;
        shiftState = 0;
        loadLayout();
        updateShiftAuto();
        refreshSuggestions();
    }

    private static boolean isWordChar(int cp) {
        int t = Character.getType(cp);
        return Character.isLetterOrDigit(cp) || cp == '\'' || cp == '’' || t == Character.NON_SPACING_MARK
                || t == Character.COMBINING_SPACING_MARK || t == Character.ENCLOSING_MARK || cp == 0x200D || cp == 0x200C;
    }

    private static boolean isWordString(String s) {
        int i = 0;
        while (i < s.length()) {
            int cp = s.codePointAt(i);
            if (!isWordChar(cp)) return false;
            i += Character.charCount(cp);
        }
        return !s.isEmpty();
    }

    private void handleText(String t) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        glideAlts = null;
        lastGlide = null;
        if (" ".equals(t)) {
            handleSpace();
            return;
        }
        if (predictionOn && isWordString(t) && !(composing.length() == 0 && t.equals("'"))) {
            composing.append(t);
            ic.setComposingText(composing, 1);
            corrOriginal = corrResult = null;
            justPicked = false;
            afterChar();
            refreshSuggestions();
            return;
        }
        boolean punct = ".,!?;:".contains(t) && t.length() == 1;
        if (composing.length() > 0) commitComposing(autoCorrectOn && punct);
        else corrOriginal = corrResult = null;
        if (justPicked && punct) {
            CharSequence before = ic.getTextBeforeCursor(1, 0);
            if (before != null && " ".contentEquals(before)) ic.deleteSurroundingText(1, 0);
            ic.commitText(t + " ", 1);
        } else {
            ic.commitText(t, 1);
        }
        justPicked = false;
        afterChar();
        if (page == Layouts.PAGE_SYM2 && "'".equals(t)) {
            page = Layouts.PAGE_LETTERS;
            loadLayout();
        }
        updateShiftAuto();
        refreshSuggestions();
    }

    private void afterChar() {
        if (isEnglish() && shiftState == 1) {
            shiftState = 0;
            kv.setShift(0);
        }
        if (page == Layouts.PAGE_SHIFT) {
            page = Layouts.PAGE_LETTERS;
            loadLayout();
        }
    }

    private void handleSpace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        long now = SystemClock.uptimeMillis();
        if (composing.length() > 0) {
            commitComposing(autoCorrectOn);
            ic.commitText(" ", 1);
            lastSpaceTime = now;
        } else {
            corrOriginal = corrResult = null;
            CharSequence before = ic.getTextBeforeCursor(2, 0);
            if (Prefs.b(this, Prefs.DOUBLE_SPACE) && now - lastSpaceTime < 900 && before != null && before.length() == 2
                    && before.charAt(1) == ' ' && Character.isLetterOrDigit(before.charAt(0))) {
                ic.deleteSurroundingText(1, 0);
                ic.commitText(isEnglish() ? ". " : "। ", 1);
                lastSpaceTime = 0;
            } else {
                ic.commitText(" ", 1);
                lastSpaceTime = now;
            }
        }
        justPicked = true;
        if (page == Layouts.PAGE_SYM || page == Layouts.PAGE_SYM2 || page == Layouts.PAGE_SHIFT) {
            page = Layouts.PAGE_LETTERS;
            loadLayout();
        }
        updateShiftAuto();
        refreshSuggestions();
    }

    private void commitComposing(boolean correct) {
        InputConnection ic = getCurrentInputConnection();
        String w = composing.toString();
        composing.setLength(0);
        if (ic == null || w.isEmpty()) return;
        String out = w;
        corrOriginal = corrResult = null;
        if (correct) {
            String c = dict.correction(w, lang());
            if (c != null && !c.equals(w)) {
                out = c;
                corrOriginal = w;
                corrResult = c;
            }
        }
        ic.commitText(out, 1);
        if (learnOn) dict.learn(out, lang(), 1);
    }

    private void handleDelete() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        glideAlts = null;
        if (lastGlide != null) {
            CharSequence b = ic.getTextBeforeCursor(lastGlide.length(), 0);
            String g = lastGlide;
            lastGlide = null;
            if (b != null && b.toString().equals(g)) {
                ic.deleteSurroundingText(g.length(), 0);
                refreshSuggestions();
                return;
            }
        }
        if (corrResult != null) {
            String tail = corrResult + " ";
            CharSequence b = ic.getTextBeforeCursor(tail.length(), 0);
            if (b != null && b.toString().equals(tail)) {
                ic.deleteSurroundingText(tail.length(), 0);
                ic.commitText(corrOriginal, 1);
                dict.learn(corrOriginal, lang(), 2);
                corrOriginal = corrResult = null;
                justPicked = false;
                refreshSuggestions();
                return;
            }
            corrOriginal = corrResult = null;
        }
        if (composing.length() > 0) {
            int cp = composing.codePointBefore(composing.length());
            composing.setLength(composing.length() - Character.charCount(cp));
            if (composing.length() > 0) ic.setComposingText(composing, 1);
            else ic.commitText("", 1);
            refreshSuggestions();
            return;
        }
        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) {
            ic.commitText("", 1);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        }
        justPicked = false;
        refreshSuggestions();
    }

    private void handleEnter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (composing.length() > 0) commitComposing(autoCorrectOn);
        corrOriginal = corrResult = null;
        glideAlts = null;
        lastGlide = null;
        justPicked = false;
        EditorInfo ei = getCurrentInputEditorInfo();
        int action = ei == null ? EditorInfo.IME_ACTION_NONE : ei.imeOptions & EditorInfo.IME_MASK_ACTION;
        boolean noEnterAction = ei != null && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else if (multi) {
            ic.commitText("\n", 1);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
        updateShiftAuto();
        refreshSuggestions();
    }

    private void updateShiftAuto() {
        if (kv == null || !isEnglish() || page != Layouts.PAGE_LETTERS || shiftState == 2) return;
        int caps = 0;
        if (Prefs.b(this, Prefs.AUTOCAP)) {
            InputConnection ic = getCurrentInputConnection();
            EditorInfo ei = getCurrentInputEditorInfo();
            if (ic != null && ei != null && ei.inputType != InputType.TYPE_NULL) caps = ic.getCursorCapsMode(ei.inputType);
        }
        shiftState = caps != 0 ? 1 : 0;
        kv.setShift(shiftState);
    }

    @Override public void onLongAction(Key k) {
        if (k.code == Key.SHIFT) {
            if (isEnglish()) {
                shiftState = 2;
                kv.setShift(2);
            }
            return;
        }
        if ((k.code == Key.SPACE || k.code == Key.LANG) && langs != null && langs.size() > 1) {
            nextLanguage();
            Toast.makeText(this, Prefs.langName(lang()), Toast.LENGTH_SHORT).show();
            return;
        }
        if (k.code == Key.SPACE || k.code == Key.LANG) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
            return;
        }
        if (k.longAction) openActivity(SettingsActivity.class, null);
    }

    @Override public void onGlide(String seq) {
        List<String> words = dict.glide(seq, lang(), 3);
        if (words.isEmpty()) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (composing.length() > 0) {
            commitComposing(false);
            ic.commitText(" ", 1);
        }
        CharSequence b = ic.getTextBeforeCursor(1, 0);
        if (b != null && b.length() > 0 && !Character.isWhitespace(b.charAt(0)) && Character.isLetterOrDigit(b.charAt(0))) {
            ic.commitText(" ", 1);
        }
        String w = words.get(0);
        if (shiftState == 2) w = w.toUpperCase(Locale.ROOT);
        else if (shiftState == 1) w = Dictionary.capitalize(w);
        if ("i".equals(w)) w = "I";
        ic.commitText(w + " ", 1);
        if (learnOn) dict.learn(w, lang(), 1);
        lastGlide = w + " ";
        glideAlts = words.size() > 1 ? words : null;
        justPicked = true;
        corrOriginal = corrResult = null;
        if (shiftState == 1) {
            shiftState = 0;
            kv.setShift(0);
        }
        refreshSuggestions();
    }

    @Override public void onCursorMove(int steps) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (composing.length() > 0) {
            ic.finishComposingText();
            composing.setLength(0);
        }
        int code = steps > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT;
        for (int i = 0; i < Math.abs(steps); i++) sendDownUpKeyEvents(code);
    }

    // ================================================================ voice typing

    private String voiceLang() {
        String v = Prefs.s(this, Prefs.VOICE_LANG);
        if (!"auto".equals(v)) return v;
        switch (lang()) {
            case "hi":
            case "bho": return "hi-IN";
            case "mr": return "mr-IN";
            default: return "en-IN";
        }
    }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Intent i = new Intent(this, PermissionActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            Toast.makeText(this, "Allow microphone for voice typing", Toast.LENGTH_LONG).show();
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Voice typing needs the Google app (speech services)", Toast.LENGTH_LONG).show();
            return;
        }
        if (composing.length() > 0) commitComposing(false);
        stopVoice();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { showStatus("🎤 Listening… speak now"); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { showStatus("Processing…"); }
            @Override public void onError(int error) {
                String msg = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        ? "Didn't catch that. Tap mic to try again" : "Voice typing error (" + error + ")";
                finishVoice();
                showStatus(msg);
                main.postDelayed(() -> { if (!listening) refreshSuggestions(); }, 1800);
            }
            @Override public void onResults(Bundle results) {
                List<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                finishVoice();
                if (r != null && !r.isEmpty()) {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) {
                        String text = r.get(0);
                        CharSequence b = ic.getTextBeforeCursor(1, 0);
                        if (b != null && b.length() > 0 && !Character.isWhitespace(b.charAt(0))) text = " " + text;
                        ic.commitText(text, 1);
                    }
                }
                refreshSuggestions();
            }
            @Override public void onPartialResults(Bundle partial) {
                List<String> r = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty() && !r.get(0).isEmpty()) showStatus("🎤 " + r.get(0));
            }
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLang());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        listening = true;
        if (micBtn != null) micBtn.setColorFilter(0xFFE53935);
        showStatus("Starting microphone…");
        try {
            recognizer.startListening(intent);
        } catch (Exception e) {
            finishVoice();
            Toast.makeText(this, "Voice typing not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void finishVoice() {
        listening = false;
        if (micBtn != null && theme != null) micBtn.setColorFilter(theme.keyText);
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    private void stopVoice() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }
        boolean was = listening;
        finishVoice();
        if (was) refreshSuggestions();
    }

    // ================================================================ network helpers

    private static String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TypeMate");
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private static void download(String u, File f) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(20000);
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            c.disconnect();
        }
    }
}
