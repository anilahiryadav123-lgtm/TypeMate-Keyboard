package com.typemate.keyboard;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Theme Store: live preview + one-tap apply. */
public class ThemeStoreActivity extends Activity {
    private static final String[] CATS = {"All", KeyboardTheme.LIGHT, KeyboardTheme.DARK, KeyboardTheme.GRADIENT, KeyboardTheme.COLORFUL};
    private String category = "All";
    private KeyboardTheme selected;
    private ThemePreviewView bigPreview;
    private TextView bigName, applyBtn;
    private LinearLayout grid, chipRow;
    private final List<TextView> chips = new ArrayList<>();
    private final List<Object[]> cards = new ArrayList<>(); // {theme, card, applyLabel}

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.HEADER);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        selected = ThemeRegistry.get(Prefs.s(this, Prefs.THEME));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(Ui.header(this, "Theme Store", true));

        // big live preview
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 14);
        top.setPadding(p, p / 2, p, p / 2);
        bigPreview = new ThemePreviewView(this);
        top.addView(bigPreview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 180)));
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(this, 8), 0, 0);
        bigName = new TextView(this);
        bigName.setTextColor(Ui.TEXT);
        bigName.setTextSize(18);
        bigName.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(bigName, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        applyBtn = Ui.button(this, "Apply Theme", Ui.BLUE, 0xFFFFFFFF);
        applyBtn.setOnClickListener(v -> apply(selected));
        bar.addView(applyBtn);
        top.addView(bar);
        root.addView(top);

        // categories
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        hs.addView(chipRow);
        for (final String c : CATS) {
            TextView chip = new TextView(this);
            chip.setText(c.equals("All") ? "All (" + ThemeRegistry.all().size() + ")" : c);
            chip.setTextSize(14);
            chip.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8));
            chip.setOnClickListener(v -> {
                category = c;
                buildGrid();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
            chipRow.addView(chip, lp);
            chips.add(chip);
        }
        root.addView(hs);

        ScrollView sv = new ScrollView(this);
        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), Ui.dp(this, 16));
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        EditText test = new EditText(this);
        test.setHint("Type here to test the applied theme…");
        test.setSingleLine(true);
        test.setBackground(Ui.card(this, 0xFFFFFFFF, 0xFFD0D4E4));
        test.setPadding(p, p, p, p);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tl.setMargins(p, p / 2, p, p / 2);
        root.addView(test, tl);

        setContentView(root);
        showSelected();
        buildGrid();
    }

    private void showSelected() {
        bigPreview.setTheme(selected);
        boolean applied = selected.id.equals(Prefs.s(this, Prefs.THEME));
        bigName.setText(selected.name + (applied ? "  ✓" : ""));
        applyBtn.setText(applied ? "Applied" : "Apply Theme");
        applyBtn.setAlpha(applied ? 0.6f : 1f);
    }

    private void apply(KeyboardTheme t) {
        Prefs.sp(this).edit().putString(Prefs.THEME, t.id).apply();
        selected = t;
        Toast.makeText(this, t.name + " applied", Toast.LENGTH_SHORT).show();
        showSelected();
        refreshCards();
    }

    private void refreshCards() {
        String current = Prefs.s(this, Prefs.THEME);
        for (Object[] o : cards) {
            KeyboardTheme t = (KeyboardTheme) o[0];
            boolean applied = t.id.equals(current);
            ((View) o[1]).setBackground(Ui.card(this, 0xFFFFFFFF, t == selected ? Ui.BLUE : (applied ? 0xFF34A853 : 0)));
            TextView ap = (TextView) o[2];
            ap.setText(applied ? "✓" : "Apply");
            ap.setTextColor(applied ? 0xFF34A853 : Ui.BLUE);
        }
    }

    private void buildGrid() {
        cards.clear();
        for (int i = 0; i < chips.size(); i++) {
            boolean on = CATS[i].equals(category);
            chips.get(i).setBackground(Ui.card(this, on ? Ui.BLUE : 0xFFFFFFFF, on ? 0 : 0xFFD0D4E4));
            chips.get(i).setTextColor(on ? 0xFFFFFFFF : Ui.TEXT);
        }
        grid.removeAllViews();
        String current = Prefs.s(this, Prefs.THEME);
        LinearLayout row = null;
        int n = 0;
        for (final KeyboardTheme t : ThemeRegistry.all()) {
            if (!"All".equals(category) && !t.category.equals(category)) continue;
            if (n % 2 == 0) {
                row = new LinearLayout(this);
                grid.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            n++;
            boolean applied = t.id.equals(current);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            int pad = Ui.dp(this, 8);
            card.setPadding(pad, pad, pad, pad);
            card.setBackground(Ui.card(this, 0xFFFFFFFF, t == selected ? Ui.BLUE : (applied ? 0xFF34A853 : 0)));
            ThemePreviewView pv = new ThemePreviewView(this);
            pv.setTheme(t);
            pv.setLabels(false);
            card.addView(pv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 96)));
            LinearLayout info = new LinearLayout(this);
            info.setGravity(Gravity.CENTER_VERTICAL);
            info.setPadding(0, Ui.dp(this, 6), 0, 0);
            TextView name = new TextView(this);
            name.setText(t.name);
            name.setTextColor(Ui.TEXT);
            name.setTextSize(14);
            name.setSingleLine(true);
            info.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView ap = new TextView(this);
            ap.setText(applied ? "✓" : "Apply");
            ap.setTextColor(applied ? 0xFF34A853 : Ui.BLUE);
            ap.setTypeface(Typeface.DEFAULT_BOLD);
            ap.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
            ap.setOnClickListener(v -> apply(t));
            info.addView(ap);
            card.addView(info);
            cards.add(new Object[]{t, card, ap});
            card.setOnClickListener(v -> {
                selected = t;
                showSelected();
                refreshCards();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
            row.addView(card, lp);
        }
        if (row != null && n % 2 == 1) {
            View filler = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
            lp.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
            row.addView(filler, lp);
        }
    }
}
