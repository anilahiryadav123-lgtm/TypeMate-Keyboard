package com.typemate.keyboard;

import android.graphics.RectF;

public class Key {
    public static final int NORMAL = 0;
    public static final int SHIFT = -1;
    public static final int SYM = -2;
    public static final int ABC = -3;
    public static final int ENTER = -4;
    public static final int DEL = -5;
    public static final int SYM2 = -6;
    public static final int EMOJI = -7;
    public static final int LANG = -8;
    public static final int SPACE = -9;
    public static final int SPACER = -100;

    public String label;
    public String out;
    public final int code;
    public final float weight;
    public String[] alts;
    public String hint;
    public boolean numberRow;
    public boolean styleFunc;
    public boolean plain;
    public boolean longAction;
    public final RectF rect = new RectF();

    public Key(String label, int code, float weight) {
        this.label = label;
        this.code = code;
        this.weight = weight;
    }

    public boolean isFunc() {
        return code < 0 && code != SPACE && code != SPACER;
    }
}
