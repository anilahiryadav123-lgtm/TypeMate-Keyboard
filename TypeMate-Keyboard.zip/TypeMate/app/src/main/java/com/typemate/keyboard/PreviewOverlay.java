package com.typemate.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Transparent layer above the whole keyboard that draws key previews and the long-press accent popup. */
public class PreviewOverlay extends View {
    private KeyboardTheme theme;
    private final float dp;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RectF pvRect;
    private String pvLabel;
    private RectF altRect;
    private String[] alts;
    private int altIdx;
    private float altCell;

    public PreviewOverlay(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        text.setTextAlign(Paint.Align.CENTER);
        setClickable(false);
        setFocusable(false);
    }

    /** Never ask for more height than the keyboard itself needs (otherwise the keyboard window fills the screen). */
    @Override protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = MeasureSpec.getMode(hSpec) == MeasureSpec.EXACTLY ? MeasureSpec.getSize(hSpec) : 0;
        setMeasuredDimension(w, h);
    }

    public void setTheme(KeyboardTheme t) { theme = t; }

    public void showPreview(RectF key, String label) {
        float w = key.width() * 1.15f, h = key.height() * 1.25f;
        float left = Math.max(0, Math.min(getWidth() - w, key.centerX() - w / 2));
        float top = Math.max(0, key.top - h + 2 * dp);
        pvRect = new RectF(left, top, left + w, top + h);
        pvLabel = label;
        alts = null;
        invalidate();
    }

    public void showAlts(RectF r, String[] a, int idx, float cell) {
        if (r.top < 0) r.offset(0, -r.top);
        altRect = r;
        alts = a;
        altIdx = idx;
        altCell = cell;
        pvLabel = null;
        invalidate();
    }

    public void setAltIndex(int i) { altIdx = i; invalidate(); }

    public void clear() {
        if (pvLabel == null && alts == null) return;
        pvLabel = null;
        alts = null;
        invalidate();
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent event) { return false; }

    @Override protected void onDraw(Canvas c) {
        if (theme == null) return;
        float rad = 10 * dp;
        if (pvLabel != null && pvRect != null) {
            fill.setColor(0x40000000);
            c.drawRoundRect(pvRect.left, pvRect.top + 2 * dp, pvRect.right, pvRect.bottom + 2 * dp, rad, rad, fill);
            fill.setColor(theme.popupBg);
            c.drawRoundRect(pvRect, rad, rad, fill);
            text.setColor(theme.popupText);
            text.setTextSize(30 * dp);
            text.setTypeface(Typeface.DEFAULT);
            Paint.FontMetrics fm = text.getFontMetrics();
            c.drawText(pvLabel, pvRect.centerX(), pvRect.top + pvRect.height() * 0.45f - (fm.ascent + fm.descent) / 2, text);
        }
        if (alts != null && altRect != null) {
            fill.setColor(0x50000000);
            c.drawRoundRect(altRect.left, altRect.top + 3 * dp, altRect.right, altRect.bottom + 3 * dp, rad, rad, fill);
            fill.setColor(theme.popupBg);
            c.drawRoundRect(altRect, rad, rad, fill);
            text.setTextSize(22 * dp);
            for (int i = 0; i < alts.length; i++) {
                float l = altRect.left + i * altCell;
                RectF cell = new RectF(l + 2 * dp, altRect.top + 3 * dp, l + altCell - 2 * dp, altRect.bottom - 3 * dp);
                if (i == altIdx) {
                    fill.setColor(theme.accent);
                    c.drawRoundRect(cell, 8 * dp, 8 * dp, fill);
                    text.setColor(KeyboardTheme.onColor(theme.accent));
                } else {
                    text.setColor(theme.popupText);
                }
                Paint.FontMetrics fm = text.getFontMetrics();
                c.drawText(alts[i], cell.centerX(), cell.centerY() - (fm.ascent + fm.descent) / 2, text);
            }
        }
    }
}
