package com.typemate.keyboard;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** All the sub pages of settings. */
public class SettingsDetailActivity extends Activity {
    private String page;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        page = getIntent().getStringExtra("page");
        if (page == null) page = "preferences";
        build();
    }

    private void build() {
        switch (page) {
            case "languages": languages(); break;
            case "corrections": corrections(); break;
            case "glide": glide(); break;
            case "voice": voice(); break;
            case "clipboard": clipboard(); break;
            case "emoji": emoji(); break;
            case "sound": sound(); break;
            case "privacy": privacy(); break;
            case "about": about(); break;
            case "help": help(); break;
            default: preferences();
        }
    }

    private void languages() {
        LinearLayout body = Ui.page(this, "Languages", true);
        Ui.note(this, body, "Choose the keyboards you type in. When more than one is on, tap the 🌐 key to switch.");
        final SharedPreferences sp = Prefs.sp(this);
        final List<String> on = new ArrayList<>(Prefs.langs(this));
        final List<CheckBox> boxes = new ArrayList<>();
        for (final String code : Prefs.ALL_LANGS) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 24), Ui.dp(this, 10), Ui.dp(this, 20), Ui.dp(this, 10));
            row.setMinimumHeight(Ui.dp(this, 68));
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            TextView a = new TextView(this);
            a.setText(Prefs.langEnglishName(code));
            a.setTextColor(Ui.TEXT);
            a.setTextSize(18);
            TextView s = new TextView(this);
            s.setText(code.equals("en") ? "QWERTY" : Prefs.langName(code) + " • Devanagari");
            s.setTextColor(Ui.SUB);
            t.addView(a);
            t.addView(s);
            row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            final CheckBox cb = new CheckBox(this);
            cb.setChecked(on.contains(code));
            cb.setOnCheckedChangeListener((btn, checked) -> {
                if (checked) {
                    if (!on.contains(code)) on.add(code);
                } else {
                    if (on.size() <= 1) {
                        btn.setChecked(true);
                        Toast.makeText(this, "Keep at least one language", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    on.remove(code);
                }
                StringBuilder v = new StringBuilder();
                for (String l : Prefs.ALL_LANGS) if (on.contains(l)) { if (v.length() > 0) v.append(','); v.append(l); }
                sp.edit().putString(Prefs.LANGS, v.toString()).putInt(Prefs.LANG_INDEX, 0).apply();
            });
            boxes.add(cb);
            row.addView(cb);
            row.setOnClickListener(v -> cb.toggle());
            body.addView(row);
        }
        Ui.section(this, body, "Tips");
        Ui.note(this, body, "• Long press the space bar to switch to another keyboard app.\n• Hindi, Marathi and Bhojpuri use the Devanagari layout. Press ⇧ for more letters (औ ऐ आ ई ऊ भ घ …).\n• Long press क ज त र न स for क्ष ज्ञ त्र ऋ ण ष.");
    }

    private void preferences() {
        LinearLayout body = Ui.page(this, "Preferences", true);
        Ui.section(this, body, "Keys");
        Ui.switchItem(this, body, Prefs.NUMBER_ROW, "Number row", "Show a number row above the letters");
        Ui.switchItem(this, body, Prefs.EMOJI_KEY, "Emoji switch key", "Show the emoji key next to the space bar");
        Ui.switchItem(this, body, Prefs.KEY_BORDERS, "Key borders", "Draw an outline around every key");
        Ui.switchItem(this, body, Prefs.KEY_POPUP, "Popup on keypress", "Show a big letter above the key you press");
        Ui.seekItem(this, body, Prefs.LONG_DELAY, "Long press delay", 150, 800, " ms");
        Ui.section(this, body, "Layout");
        Ui.seekItem(this, body, Prefs.HEIGHT, "Keyboard height", 70, 140, "%");
        Ui.choiceItem(this, body, Prefs.ONE_HANDED, "One-handed mode",
                new String[]{"Off", "Left hand", "Right hand"}, new String[]{"0", "1", "2"});
        Ui.section(this, body, "Font & key size");
        Ui.seekItem(this, body, Prefs.TEXT_SIZE, "Key text size", 70, 140, "%");
        Ui.switchItem(this, body, Prefs.BOLD, "Bold key text", null);
        Ui.section(this, body, "Sound & vibration");
        Ui.switchItem(this, body, Prefs.SOUND, "Sound on keypress", null);
        Ui.seekItem(this, body, Prefs.SOUND_VOL, "Keypress volume", 0, 100, "%");
        Ui.switchItem(this, body, Prefs.VIBRATE, "Haptic feedback on keypress", null);
        Ui.seekItem(this, body, Prefs.VIB_MS, "Vibration strength", 5, 60, " ms");
    }

    private void sound() {
        LinearLayout body = Ui.page(this, "Sound & vibration", true);
        Ui.switchItem(this, body, Prefs.SOUND, "Sound on keypress", null);
        Ui.seekItem(this, body, Prefs.SOUND_VOL, "Keypress volume", 0, 100, "%");
        Ui.switchItem(this, body, Prefs.VIBRATE, "Haptic feedback on keypress", null);
        Ui.seekItem(this, body, Prefs.VIB_MS, "Vibration strength", 5, 60, " ms");
        Ui.note(this, body, "Keypress sound follows your phone's system sound volume.");
    }

    private void corrections() {
        LinearLayout body = Ui.page(this, "Corrections & suggestions", true);
        Ui.section(this, body, "Suggestions");
        Ui.switchItem(this, body, Prefs.SUGGEST, "Show suggestion strip", "Word suggestions above the keyboard");
        Ui.section(this, body, "Corrections");
        Ui.switchItem(this, body, Prefs.AUTOCORRECT, "Auto-correction", "Fix misspelled words when you press space or punctuation");
        Ui.switchItem(this, body, Prefs.AUTOCAP, "Auto-capitalization", "Capitalize the first word of each sentence");
        Ui.switchItem(this, body, Prefs.DOUBLE_SPACE, "Double-space period", "Double tap space bar to insert a full stop");
        Ui.note(this, body, "Tip: press ⌫ right after an auto-correction to undo it. Long press a suggestion to save it.");
    }

    private void glide() {
        LinearLayout body = Ui.page(this, "Glide typing", true);
        Ui.switchItem(this, body, Prefs.GLIDE, "Enable glide typing", "Type a word by sliding through the letters (English)");
        Ui.switchItem(this, body, Prefs.GLIDE_TRAIL, "Show gesture trail", null);
        Ui.switchItem(this, body, Prefs.NUMBER_ROW, "Number row", null);
        Ui.note(this, body, "Slide on the space bar to move the cursor left or right.");
    }

    private void voice() {
        LinearLayout body = Ui.page(this, "Voice typing", true);
        Ui.switchItem(this, body, Prefs.VOICE, "Use voice typing", "Show the microphone button on the keyboard");
        Ui.choiceItem(this, body, Prefs.VOICE_LANG, "Voice language",
                new String[]{"Same as keyboard", "English (India)", "English (US)", "Hindi", "Marathi"},
                new String[]{"auto", "en-IN", "en-US", "hi-IN", "mr-IN"});
        boolean ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        Ui.item(this, body, 0, "Microphone permission", ok ? "Allowed ✅" : "Tap to allow", () ->
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 3));
        Ui.note(this, body, "Voice typing uses your phone's speech service (Google app). Bhojpuri voice uses Hindi recognition.");
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        build();
    }

    private void clipboard() {
        LinearLayout body = Ui.page(this, "Clipboard", true);
        Ui.switchItem(this, body, Prefs.CLIPBOARD, "Clipboard history", "Save text you copy so you can paste it later");
        Ui.seekItem(this, body, Prefs.CLIP_MAX, "Items to keep", 5, 100, "");
        Ui.item(this, body, R.drawable.ic_delete, "Clear clipboard history", ClipHistory.get(this).size() + " items saved", () -> {
            ClipHistory.clear(this);
            Toast.makeText(this, "Clipboard cleared", Toast.LENGTH_SHORT).show();
            build();
        });
        Ui.note(this, body, "Open clipboard from the 📋 button on the keyboard toolbar. History is stored only on this phone.");
    }

    private void emoji() {
        LinearLayout body = Ui.page(this, "Emojis, Stickers & GIFs", true);
        Ui.section(this, body, "Emoji");
        Ui.switchItem(this, body, Prefs.EMOJI_KEY, "Emoji switch key", "Show emoji key next to the space bar");
        Ui.item(this, body, R.drawable.ic_delete, "Clear recent emojis", null, () -> {
            Prefs.data(this).edit().remove("emoji_recent").apply();
            Toast.makeText(this, "Recent emojis cleared", Toast.LENGTH_SHORT).show();
        });
        Ui.section(this, body, "Stickers");
        Ui.note(this, body, StickerMaker.STICKERS.length + " built-in stickers work offline. Apps like WhatsApp accept them directly; in other apps you choose the chat from the share menu.");
        Ui.section(this, body, "GIFs");
        Ui.textItem(this, body, Prefs.GIPHY_KEY, "GIPHY API key", "Paste your GIPHY API key");
        Ui.note(this, body, "GIF search needs a free GIPHY key:\n1. Open developers.giphy.com and sign up\n2. Create an App → choose API\n3. Copy the key and paste it above");
        Ui.item(this, body, R.drawable.ic_gif, "Open developers.giphy.com", null, () ->
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://developers.giphy.com/dashboard/"))));
    }

    private void privacy() {
        LinearLayout body = Ui.page(this, "Privacy", true);
        Ui.switchItem(this, body, Prefs.LEARN, "Personalized suggestions", "Learn new words you type to improve suggestions (stored on this phone)");
        Ui.item(this, body, R.drawable.ic_delete, "Delete learned words", null, () -> new AlertDialog.Builder(this)
                .setMessage("Delete all words TypeMate learned from your typing?")
                .setPositiveButton("Delete", (d, w) -> {
                    new Dictionary(this).clearLearned();
                    Toast.makeText(this, "Learned words deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null).show());
        Ui.note(this, body, "TypeMate does not send your typing anywhere. Passwords are never learned or suggested. "
                + "Internet is used only when you choose Translate (text goes to Google Translate) or GIFs (GIPHY).");
    }

    private void about() {
        LinearLayout body = Ui.page(this, "About", true);
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(0, Ui.dp(this, 24), 0, Ui.dp(this, 12));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        hero.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 110), Ui.dp(this, 110)));
        TextView n = new TextView(this);
        n.setText("TypeMate Keyboard");
        n.setTextSize(22);
        n.setTextColor(Ui.TEXT);
        n.setPadding(0, Ui.dp(this, 10), 0, 0);
        hero.addView(n);
        body.addView(hero);
        String version = "1.0";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        Ui.item(this, body, R.drawable.ic_info, "Version", version, null);
        Ui.item(this, body, R.drawable.ic_star, "Developer", "Anil Yadav", null);
        Ui.item(this, body, R.drawable.ic_globe, "Made in India 🇮🇳", "English • हिन्दी • मराठी • भोजपुरी", null);
        Ui.item(this, body, R.drawable.ic_palette, "Themes", ThemeRegistry.all().size() + " built-in themes", null);
    }

    private void help() {
        LinearLayout body = Ui.page(this, "Help & feedback", true);
        String[][] faq = {
                {"How do I turn on TypeMate?", "Open the TypeMate app → tap 'Enable TypeMate' → switch it on → go back and tap 'Select TypeMate'."},
                {"How do I type in Hindi / Marathi / Bhojpuri?", "Settings → Languages → tick the language. Then tap the 🌐 key on the keyboard to switch."},
                {"How do I change the theme?", "Tap the 🎨 palette on the keyboard toolbar or open Theme Store, pick a theme and tap Apply."},
                {"Voice typing doesn't work", "Allow microphone permission and make sure the Google app is installed and updated."},
                {"How do I undo an auto-correction?", "Press backspace right after the word was corrected."},
                {"How do I move the cursor?", "Slide your finger left or right on the space bar, or use Text editing from the menu."},
                {"GIFs are not loading", "Add a free GIPHY API key in Settings → Emojis, Stickers & GIFs."},
        };
        for (String[] f : faq) {
            Ui.section(this, body, f[0]);
            Ui.note(this, body, f[1]);
        }
        Ui.section(this, body, "Feedback");
        Ui.item(this, body, R.drawable.ic_help, "Send feedback", "Tell us what to improve", () -> {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
            i.putExtra(Intent.EXTRA_SUBJECT, "TypeMate Keyboard feedback");
            try {
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
