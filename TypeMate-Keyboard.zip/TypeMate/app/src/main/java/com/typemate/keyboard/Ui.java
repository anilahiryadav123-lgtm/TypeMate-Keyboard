package com.typemate.keyboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Small helper to build clean Gboard-style settings screens in code. */
public final class Ui {
    public static final int BG = 0xFFEEEEF4;
    public static final int HEADER = 0xFFE3E4EA;
    public static final int TEXT = 0xFF1F1F1F;
    public static final int SUB = 0xFF5F6368;
    public static final int ICON = 0xFF444746;
    public static final int BLUE = 0xFF0B57D0;

    private Ui() {}

    public static int dp(Activity a, float v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    /** Sets up a page with a header (back arrow + title) and returns the scrollable body. */
    public static LinearLayout page(final Activity a, String title, boolean back) {
        a.getWindow().setStatusBarColor(HEADER);
        a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.addView(header(a, title, back));
        ScrollView sv = new ScrollView(a);
        sv.setId(View.generateViewId());
        LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(a, 6), 0, dp(a, 24));
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        a.setContentView(root);
        return body;
    }

    public static View header(final Activity a, String title, boolean back) {
        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setBackgroundColor(HEADER);
        h.setPadding(dp(a, 8), 0, dp(a, 16), 0);
        if (back) {
            ImageView iv = new ImageView(a);
            iv.setImageResource(R.drawable.ic_back);
            iv.setColorFilter(TEXT);
            iv.setScaleType(ImageView.ScaleType.CENTER);
            iv.setBackgroundResource(selectable(a, true));
            iv.setOnClickListener(v -> a.finish());
            h.addView(iv, new LinearLayout.LayoutParams(dp(a, 48), dp(a, 48)));
        } else {
            View sp = new View(a);
            h.addView(sp, new LinearLayout.LayoutParams(dp(a, 12), 1));
        }
        TextView t = new TextView(a);
        t.setText(title);
        t.setTextColor(TEXT);
        t.setTextSize(22);
        t.setPadding(dp(a, 14), 0, 0, 0);
        t.setSingleLine(true);
        h.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        h.setMinimumHeight(dp(a, 64));
        return h;
    }

    public static int selectable(Activity a, boolean borderless) {
        TypedValue tv = new TypedValue();
        a.getTheme().resolveAttribute(borderless ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        return tv.resourceId;
    }

    public static void section(Activity a, LinearLayout body, String title) {
        TextView t = new TextView(a);
        t.setText(title);
        t.setTextColor(BLUE);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(a, 24), dp(a, 18), dp(a, 24), dp(a, 6));
        body.addView(t);
    }

    public static void note(Activity a, LinearLayout body, String text) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextColor(SUB);
        t.setTextSize(14);
        t.setPadding(dp(a, 24), dp(a, 8), dp(a, 24), dp(a, 8));
        body.addView(t);
    }

    /** A row with optional icon, title, summary. Returns the summary TextView. */
    public static TextView item(Activity a, LinearLayout body, int icon, String title, String summary, final Runnable click) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(a, 24), dp(a, 14), dp(a, 20), dp(a, 14));
        row.setMinimumHeight(dp(a, 72));
        row.setBackgroundResource(selectable(a, false));
        if (icon != 0) {
            ImageView iv = new ImageView(a);
            iv.setImageResource(icon);
            iv.setColorFilter(ICON);
            row.addView(iv, new LinearLayout.LayoutParams(dp(a, 28), dp(a, 28)));
            row.addView(new View(a), new LinearLayout.LayoutParams(dp(a, 26), 1));
        }
        LinearLayout texts = new LinearLayout(a);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(a);
        t.setText(title);
        t.setTextColor(TEXT);
        t.setTextSize(icon != 0 ? 20 : 17);
        texts.addView(t);
        TextView s = new TextView(a);
        s.setTextColor(SUB);
        s.setTextSize(14);
        if (summary != null && !summary.isEmpty()) s.setText(summary); else s.setVisibility(View.GONE);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (click != null) row.setOnClickListener(v -> click.run());
        body.addView(row);
        return s;
    }

    public static Switch switchItem(Activity a, LinearLayout body, final String key, String title, String summary) {
        final SharedPreferences sp = Prefs.sp(a);
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(a, 24), dp(a, 12), dp(a, 20), dp(a, 12));
        row.setMinimumHeight(dp(a, 64));
        row.setBackgroundResource(selectable(a, false));
        LinearLayout texts = new LinearLayout(a);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(a);
        t.setText(title);
        t.setTextColor(TEXT);
        t.setTextSize(17);
        texts.addView(t);
        if (summary != null) {
            TextView s = new TextView(a);
            s.setText(summary);
            s.setTextColor(SUB);
            s.setTextSize(14);
            texts.addView(s);
        }
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final Switch sw = new Switch(a);
        sw.setChecked(sp.getBoolean(key, Prefs.defBool(key)));
        sw.setOnCheckedChangeListener((b, c) -> sp.edit().putBoolean(key, c).apply());
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        body.addView(row);
        return sw;
    }

    public static void seekItem(Activity a, LinearLayout body, final String key, final String title,
                                final int min, final int max, final String unit) {
        final SharedPreferences sp = Prefs.sp(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(a, 24), dp(a, 12), dp(a, 20), dp(a, 8));
        final TextView t = new TextView(a);
        t.setTextColor(TEXT);
        t.setTextSize(17);
        int v = sp.getInt(key, Prefs.defInt(key));
        t.setText(title + ": " + v + unit);
        col.addView(t);
        SeekBar sb = new SeekBar(a);
        sb.setMax(max - min);
        sb.setProgress(v - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                t.setText(title + ": " + (p + min) + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {
                sp.edit().putInt(key, s.getProgress() + min).apply();
            }
        });
        col.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 40)));
        body.addView(col);
    }

    public static void choiceItem(final Activity a, LinearLayout body, final String key, final String title,
                                  final String[] labels, final String[] values) {
        final SharedPreferences sp = Prefs.sp(a);
        String cur = sp.getString(key, Prefs.defStr(key));
        int idx = 0;
        for (int i = 0; i < values.length; i++) if (values[i].equals(cur)) idx = i;
        final TextView[] sum = new TextView[1];
        final int[] sel = {idx};
        sum[0] = item(a, body, 0, title, labels[idx], () -> new AlertDialog.Builder(a)
                .setTitle(title)
                .setSingleChoiceItems(labels, sel[0], (d, w) -> {
                    sel[0] = w;
                    sp.edit().putString(key, values[w]).apply();
                    sum[0].setText(labels[w]);
                    d.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show());
    }

    public static void textItem(final Activity a, LinearLayout body, final String key, final String title, final String hint) {
        final SharedPreferences sp = Prefs.sp(a);
        String cur = sp.getString(key, Prefs.defStr(key));
        final TextView[] sum = new TextView[1];
        sum[0] = item(a, body, 0, title, cur.isEmpty() ? "Not set" : mask(cur), () -> {
            final EditText e = new EditText(a);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setHint(hint);
            e.setText(sp.getString(key, ""));
            int p = dp(a, 20);
            LinearLayout wrap = new LinearLayout(a);
            wrap.setPadding(p, p / 2, p, 0);
            wrap.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            new AlertDialog.Builder(a).setTitle(title).setView(wrap)
                    .setPositiveButton("Save", (d, w) -> {
                        String v = e.getText().toString().trim();
                        sp.edit().putString(key, v).apply();
                        sum[0].setText(v.isEmpty() ? "Not set" : mask(v));
                    })
                    .setNegativeButton("Cancel", null).show();
        });
    }

    private static String mask(String s) {
        if (s.length() <= 6) return "••••••";
        return s.substring(0, 4) + "••••••" + s.substring(s.length() - 2);
    }

    public static TextView button(Activity a, String label, int bg, int fg) {
        TextView b = new TextView(a);
        b.setText(label);
        b.setTextColor(fg);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(a, 18), dp(a, 12), dp(a, 18), dp(a, 12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(a, 26));
        b.setBackground(g);
        return b;
    }

    public static GradientDrawable card(Activity a, int color, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(a, 16));
        if (strokeColor != 0) g.setStroke(dp(a, 2), strokeColor);
        return g;
    }
}
