package com.typemate.keyboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.RatingBar;

/** Main settings list, laid out like Gboard settings. */
public class SettingsActivity extends Activity {

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        build();
    }

    private void build() {
        LinearLayout body = Ui.page(this, "TypeMate settings", true);
        StringBuilder ls = new StringBuilder();
        for (String l : Prefs.langs(this)) {
            if (ls.length() > 0) ls.append(", ");
            ls.append(Prefs.langEnglishName(l)).append(l.equals("en") ? " (QWERTY)" : " (" + Prefs.langName(l) + ")");
        }
        Ui.item(this, body, R.drawable.ic_globe, "Languages", ls.toString(), () -> open("languages"));
        Ui.item(this, body, R.drawable.ic_tune, "Preferences", null, () -> open("preferences"));
        Ui.item(this, body, R.drawable.ic_palette, "Theme", ThemeRegistry.get(Prefs.s(this, Prefs.THEME)).name, () ->
                startActivity(new Intent(this, ThemeStoreActivity.class)));
        Ui.item(this, body, R.drawable.ic_spell, "Corrections & suggestions", null, () -> open("corrections"));
        Ui.item(this, body, R.drawable.ic_gesture, "Glide typing", null, () -> open("glide"));
        Ui.item(this, body, R.drawable.ic_mic, "Voice typing", null, () -> open("voice"));
        Ui.item(this, body, R.drawable.ic_clipboard, "Clipboard", null, () -> open("clipboard"));
        Ui.item(this, body, R.drawable.ic_book, "Dictionary", null, () ->
                startActivity(new Intent(this, DictionaryActivity.class)));
        Ui.item(this, body, R.drawable.ic_emoji, "Emojis, Stickers & GIFs", null, () -> open("emoji"));
        Ui.item(this, body, R.drawable.ic_volume, "Sound & vibration", null, () -> open("sound"));
        Ui.item(this, body, R.drawable.ic_share, "Share TypeMate", null, () -> {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, "Try TypeMate Keyboard – a fast keyboard with 100+ themes, Hindi, Marathi & Bhojpuri typing. Download: https://anilyadavapps.blogspot.com");
            startActivity(Intent.createChooser(s, "Share TypeMate"));
        });
        Ui.item(this, body, R.drawable.ic_shield, "Privacy", null, () -> open("privacy"));
        Ui.item(this, body, R.drawable.ic_star, "Rate us", null, this::rate);
        Ui.item(this, body, R.drawable.ic_info, "About", null, () -> open("about"));
        Ui.item(this, body, R.drawable.ic_help, "Help & feedback", null, () -> open("help"));
    }

    private void open(String page) {
        startActivity(new Intent(this, SettingsDetailActivity.class).putExtra("page", page));
    }

    private void rate() {
        final RatingBar rb = new RatingBar(this);
        rb.setNumStars(5);
        rb.setStepSize(1f);
        rb.setRating(5f);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setGravity(android.view.Gravity.CENTER);
        wrap.setPadding(0, Ui.dp(this, 16), 0, 0);
        wrap.addView(rb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Enjoying TypeMate?")
                .setView(wrap)
                .setPositiveButton("Submit", (d, w) -> {
                    if (rb.getRating() >= 4) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
                        } catch (Exception e) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://anilyadavapps.blogspot.com")));
                        }
                    } else {
                        open("help");
                    }
                })
                .setNegativeButton("Later", null)
                .show();
    }
}
