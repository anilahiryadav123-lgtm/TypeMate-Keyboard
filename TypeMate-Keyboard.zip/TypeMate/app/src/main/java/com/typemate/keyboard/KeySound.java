package com.typemate.keyboard;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Plays a short key click that works even when system "touch sounds" are off. */
final class KeySound {
    static final int KEY = 0, SPACE = 1, DEL = 2;
    private static final int RATE = 22050;
    private static final short[][] DATA = new short[3][];
    private static final AudioTrack[] TRACKS = new AudioTrack[3];

    private static short[] make(double freq, int ms) {
        int n = RATE * ms / 1000;
        short[] d = new short[n];
        for (int i = 0; i < n; i++) {
            double env = Math.exp(-6.0 * i / n);
            d[i] = (short) (Math.sin(2 * Math.PI * freq * i / RATE) * env * 20000);
        }
        return d;
    }

    private static synchronized AudioTrack track(int type) {
        if (TRACKS[type] == null) {
            if (DATA[type] == null) {
                DATA[type] = type == SPACE ? make(520, 35) : type == DEL ? make(700, 30) : make(900, 25);
            }
            short[] d = DATA[type];
            AudioTrack t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(d.length * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            t.write(d, 0, d.length);
            TRACKS[type] = t;
        }
        return TRACKS[type];
    }

    static void play(int type, float vol) {
        try {
            AudioTrack t = track(type);
            t.setVolume(Math.max(0f, Math.min(1f, vol)));
            t.stop();
            t.reloadStaticData();
            t.play();
        } catch (Exception ignored) {
        }
    }
}
