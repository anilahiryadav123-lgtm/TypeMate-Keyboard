package com.typemate.keyboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Mobile keyboard layouts: English QWERTY, Hindi / Marathi / Bhojpuri (Devanagari), symbols and phone pad. */
public final class Layouts {
    public static final int PAGE_LETTERS = 0;
    public static final int PAGE_SHIFT = 1;   // Devanagari shifted page
    public static final int PAGE_SYM = 2;
    public static final int PAGE_SYM2 = 3;
    public static final int PAGE_PHONE = 4;

    private static final Map<String, String[]> ALTS = new HashMap<>();

    private static void alt(String k, String v) { ALTS.put(k, v.split(" ")); }

    static {
        // English accents
        alt("a", "à á â ä æ ã å ā");
        alt("e", "è é ê ë ē ę ė");
        alt("i", "ì í î ï ī į");
        alt("o", "ò ó ô ö õ ø ō œ");
        alt("u", "ù ú û ü ū");
        alt("c", "ç ć č");
        alt("n", "ñ ń");
        alt("s", "ß ś š");
        alt("y", "ý ÿ");
        alt("z", "ž ź ż");
        alt("l", "ł");
        alt("d", "ð");
        alt("g", "ğ");
        // numbers
        alt("1", "¹ ½ ⅓ ¼ ⅛ १");
        alt("2", "² ⅔ २");
        alt("3", "³ ¾ ⅜ ३");
        alt("4", "⁴ ४");
        alt("5", "⅝ ५");
        alt("6", "६");
        alt("7", "⅞ ७");
        alt("8", "८");
        alt("9", "९");
        alt("0", "ⁿ ∅ ०");
        // symbols
        alt(".", ", ? ! ' \" : ; - @ # % & * ( ) /");
        alt("₹", "$ € £ ¥ ¢ ₩");
        alt("$", "₹ € £ ¥ ¢");
        alt("-", "_ – — ·");
        alt("+", "±");
        alt("(", "< { [");
        alt(")", "> } ]");
        alt("\"", "“ ” « »");
        alt("'", "‘ ’ ‚ ‹ ›");
        alt("?", "¿");
        alt("!", "¡");
        alt("%", "‰");
        alt("*", "★ † ‡");
        alt("=", "≠ ≈ ∞");
        alt("/", "\\");
        alt("&", "§");
        alt("#", "№");
        // Devanagari
        alt("क", "क्ष क़");
        alt("ज", "ज्ञ ज़");
        alt("त", "त्र");
        alt("र", "ऋ ृ र्");
        alt("श", "श्र");
        alt("स", "ष श");
        alt("न", "ण ञ ङ");
        alt("द", "द्ध द्व");
        alt("ड", "ड़");
        alt("ढ", "ढ़");
        alt("फ", "फ़");
        alt("ग", "ग़");
        alt("ख", "ख़");
        alt("ं", "ँ ः");
        alt("ो", "ॉ");
        alt("ओ", "ऑ");
        alt("े", "ॅ");
        alt("ए", "ऍ");
        alt("ः", "ऽ");
        alt("ल", "ळ");
        alt("।", "॥ . ? ! , ' \"");
    }

    private Layouts() {}

    private static Key ch(String s) {
        Key k = new Key(s, Key.NORMAL, 1f);
        k.out = s;
        k.alts = ALTS.get(s);
        return k;
    }

    private static List<Key> chars(String spaced) {
        List<Key> r = new ArrayList<>();
        for (String s : spaced.split(" ")) r.add(ch(s));
        return r;
    }

    private static Key fn(String label, int code, float w) {
        return new Key(label, code, w);
    }

    private static List<Key> row(Key... ks) {
        List<Key> r = new ArrayList<>();
        for (Key k : ks) r.add(k);
        return r;
    }

    /** Same key with a different width weight. */
    private static Key w(Key k, float weight) {
        Key n = new Key(k.label, k.code, weight);
        n.out = k.out; n.alts = k.alts; n.hint = k.hint; n.numberRow = k.numberRow;
        n.styleFunc = k.styleFunc; n.plain = k.plain; n.longAction = k.longAction;
        return n;
    }

    private static Key styled(String s) {
        Key k = ch(s);
        k.styleFunc = true;
        return k;
    }

    public static List<List<Key>> build(String lang, int page, boolean numberRow, boolean showLang, boolean emojiKey) {
        List<List<Key>> rows = new ArrayList<>();
        boolean dev = !"en".equals(lang);

        if (page == PAGE_PHONE) {
            // Gboard-style number pad
            Key plus = styled("+"); plus.alts = new String[]{"±"};
            Key minus = styled("-"); minus.alts = new String[]{"_", "–", "—"};
            Key star = styled("*"); star.alts = new String[]{"★", "†"};
            Key slash = styled("/"); slash.alts = new String[]{"\\", "#"};
            Key tile = fn("", Key.SPACER, 0.62f);
            tile.sub = new Key[]{plus, minus, star, slash};
            Key pct = styled("%"); pct.alts = new String[]{"‰"};
            Key spc = styled("\u2423"); spc.out = " "; spc.alts = null;
            Key sym = fn("!?#", Key.SYM, 0.55f); sym.plain = true;
            Key eq = ch("="); 
            Key dot = styled("."); dot.alts = null;
            Key comma = styled(","); comma.alts = null;
            rows.add(row(tile, ch("1"), ch("2"), ch("3"), w(pct, 0.62f)));
            rows.add(row(fn("", Key.SPACER, 0.62f), ch("4"), ch("5"), ch("6"), w(spc, 0.62f)));
            rows.add(row(fn("", Key.SPACER, 0.62f), ch("7"), ch("8"), ch("9"), fn("", Key.DEL, 0.62f)));
            rows.add(row(fn("ABC", Key.ABC, 0.62f), w(comma, 0.4f), sym, w(ch("0"), 1f), w(eq, 0.55f), w(dot, 0.4f), fn("", Key.ENTER, 0.62f)));
            return rows;
        }

        boolean letters = page == PAGE_LETTERS || page == PAGE_SHIFT;
        if (numberRow && letters) {
            List<Key> nr = chars("1 2 3 4 5 6 7 8 9 0");
            for (Key k : nr) k.numberRow = true;
            rows.add(nr);
        }

        if (page == PAGE_SYM) {
            rows.add(chars("1 2 3 4 5 6 7 8 9 0"));
            rows.add(chars("@ # ₹ _ & - + ( ) /"));
            List<Key> r3 = new ArrayList<>();
            r3.add(fn("=\\<", Key.SYM2, 1.5f));
            r3.addAll(chars("* \" ' : ; ! ?"));
            r3.add(fn("", Key.DEL, 1.5f));
            rows.add(r3);
        } else if (page == PAGE_SYM2) {
            rows.add(chars("~ ` | • √ π ÷ × ¶ ∆"));
            rows.add(chars("£ € $ ¢ ^ ° = { } \\"));
            List<Key> r3 = new ArrayList<>();
            r3.add(fn("?123", Key.SYM, 1.5f));
            r3.addAll(chars("% © ® ™ ✓ [ ]"));
            r3.add(fn("", Key.DEL, 1.5f));
            rows.add(r3);
        } else if (!dev) {
            List<Key> r1 = chars("q w e r t y u i o p");
            if (!numberRow) {
                String digits = "1234567890";
                for (int i = 0; i < r1.size(); i++) {
                    Key k = r1.get(i);
                    String d = String.valueOf(digits.charAt(i));
                    k.hint = d;
                    String[] old = k.alts;
                    int n = old == null ? 0 : old.length;
                    String[] na = new String[n + 1];
                    na[0] = d;
                    for (int j = 0; j < n; j++) na[j + 1] = old[j];
                    k.alts = na;
                }
            }
            rows.add(r1);
            List<Key> r2 = new ArrayList<>();
            r2.add(fn("", Key.SPACER, 0.5f));
            r2.addAll(chars("a s d f g h j k l"));
            r2.add(fn("", Key.SPACER, 0.5f));
            rows.add(r2);
            List<Key> r3 = new ArrayList<>();
            r3.add(fn("", Key.SHIFT, 1.5f));
            r3.addAll(chars("z x c v b n m"));
            r3.add(fn("", Key.DEL, 1.5f));
            rows.add(r3);
        } else if (page == PAGE_SHIFT) {
            rows.add(chars("औ ऐ आ ई ऊ भ ङ घ ध झ ढ"));
            rows.add(chars("ओ ए अ इ उ फ ऱ ख थ छ ठ"));
            List<Key> r3 = new ArrayList<>();
            r3.add(fn("", Key.SHIFT, 1.5f));
            r3.addAll(chars("mr".equals(lang) ? "ँ ण ञ ष श ळ ः ृ" : "ँ ण ञ ष श ऋ ः ृ"));
            r3.add(fn("", Key.DEL, 1.5f));
            rows.add(r3);
        } else {
            rows.add(chars("ौ ै ा ी ू ब ह ग द ज ड"));
            rows.add(chars("ो े ् ि ु प र क त च ट"));
            List<Key> r3 = new ArrayList<>();
            r3.add(fn("", Key.SHIFT, 1.5f));
            r3.addAll(chars("mr".equals(lang) ? "ं म न व ल स य ळ" : "ं म न व ल स य ़"));
            r3.add(fn("", Key.DEL, 1.5f));
            rows.add(r3);
        }

        // bottom row
        boolean sym = page == PAGE_SYM || page == PAGE_SYM2;
        List<Key> b = new ArrayList<>();
        b.add(fn(sym ? "ABC" : "?123", sym ? Key.ABC : Key.SYM, 1.5f));
        Key comma = styled(",");
        comma.alts = null;
        comma.longAction = true;
        b.add(comma);
        float space = 5f;
        if (showLang) { b.add(fn("", Key.LANG, 1f)); space -= 1f; }
        if (emojiKey) { b.add(fn("", Key.EMOJI, 1f)); space -= 1f; }
        Key sp = fn("", Key.SPACE, space);
        sp.out = " ";
        b.add(sp);
        Key dot = styled(dev && !sym ? "।" : ".");
        b.add(dot);
        b.add(fn("", Key.ENTER, 1.5f));
        rows.add(b);
        return rows;
    }
}
