package com.typemate.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Word lists, suggestions, auto-correction, glide matching and on-device learning. */
public class Dictionary {
    private final Context ctx;
    private final Map<String, List<String>> words = new HashMap<>();
    private final Map<String, Map<String, Integer>> ranks = new HashMap<>();
    private final Map<String, Map<String, Integer>> learned = new HashMap<>();
    private static final Map<String, String> CONTRACTIONS = new HashMap<>();
    static {
        String[] c = {"dont", "don't", "cant", "can't", "wont", "won't", "didnt", "didn't", "doesnt", "doesn't",
                "isnt", "isn't", "arent", "aren't", "wasnt", "wasn't", "werent", "weren't", "havent", "haven't",
                "hasnt", "hasn't", "couldnt", "couldn't", "shouldnt", "shouldn't", "wouldnt", "wouldn't",
                "im", "I'm", "ive", "I've", "youre", "you're", "theyre", "they're", "thats", "that's",
                "whats", "what's", "lets", "let's", "youll", "you'll", "theyll", "they'll",
                "hes", "he's", "shes", "she's", "theres", "there's", "heres", "here's", "aint", "ain't", "i", "I"};
        for (int i = 0; i < c.length; i += 2) CONTRACTIONS.put(c[i], c[i + 1]);
    }

    public Dictionary(Context c) {
        ctx = c.getApplicationContext();
    }

    private synchronized List<String> list(String lang) {
        List<String> l = words.get(lang);
        if (l != null) return l;
        l = new ArrayList<>();
        Map<String, Integer> r = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(ctx.getAssets().open("dict_" + lang + ".txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                for (String w : line.trim().split("\\s+")) {
                    if (w.isEmpty()) continue;
                    String lw = w.toLowerCase(Locale.ROOT);
                    if (!r.containsKey(lw)) {
                        r.put(lw, l.size());
                        l.add(lw);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        words.put(lang, l);
        ranks.put(lang, r);
        return l;
    }

    private synchronized Map<String, Integer> learnedMap(String lang) {
        Map<String, Integer> m = learned.get(lang);
        if (m != null) return m;
        m = new HashMap<>();
        String prefix = "l_" + lang + "_";
        for (Map.Entry<String, ?> e : Prefs.data(ctx).getAll().entrySet()) {
            if (e.getKey().startsWith(prefix) && e.getValue() instanceof Integer) {
                m.put(e.getKey().substring(prefix.length()), (Integer) e.getValue());
            }
        }
        learned.put(lang, m);
        return m;
    }

    public Set<String> userWords() {
        Set<String> s = Prefs.sp(ctx).getStringSet(Prefs.USER_WORDS, null);
        Set<String> out = new HashSet<>();
        if (s != null) for (String w : s) out.add(w.toLowerCase(Locale.ROOT));
        return out;
    }

    private int score(String w, String lang, Set<String> user) {
        List<String> l = list(lang);
        Integer r = ranks.get(lang).get(w);
        int s = r == null ? 0 : (l.size() - r) * 1000 / Math.max(1, l.size());
        Integer c = learnedMap(lang).get(w);
        if (c != null) s += Math.min(c, 20) * 150;
        if (user.contains(w)) s += 1500;
        return s;
    }

    public boolean isKnown(String w, String lang) {
        String lw = w.toLowerCase(Locale.ROOT);
        list(lang);
        if (ranks.get(lang).containsKey(lw)) return true;
        if (userWords().contains(lw)) return true;
        Integer c = learnedMap(lang).get(lw);
        return c != null && c >= 2;
    }

    private Set<String> candidatesPool(String lang, Set<String> user) {
        Set<String> pool = new HashSet<>(list(lang));
        pool.addAll(learnedMap(lang).keySet());
        pool.addAll(user);
        return pool;
    }

    /** Word completions for a typed prefix. */
    public List<String> complete(String typed, String lang, int n) {
        String lower = typed.toLowerCase(Locale.ROOT);
        Set<String> user = userWords();
        List<String> found = new ArrayList<>();
        final Map<String, Integer> sc = new HashMap<>();
        for (String w : candidatesPool(lang, user)) {
            if (w.length() > lower.length() && w.startsWith(lower)) {
                found.add(w);
                sc.put(w, score(w, lang, user) - (w.length() - lower.length()) * 15);
            }
        }
        Collections.sort(found, (a, b) -> sc.get(b) - sc.get(a));
        List<String> out = new ArrayList<>();
        for (String w : found) {
            out.add(applyCase(w, typed));
            if (out.size() >= n) break;
        }
        return out;
    }

    /** Best correction for a misspelled word, or null when the word is fine. */
    public String correction(String typed, String lang) {
        if (typed.isEmpty()) return null;
        String lower = typed.toLowerCase(Locale.ROOT);
        if ("en".equals(lang)) {
            String c = CONTRACTIONS.get(lower);
            if (c != null) {
                if (c.equals(typed)) return null;
                return Character.isUpperCase(typed.charAt(0)) && !c.startsWith("I") ? capitalize(c) : c;
            }
        }
        if (typed.length() < 2 || isKnown(typed, lang)) return null;
        for (int i = 0; i < typed.length(); i++) if (Character.isDigit(typed.charAt(i))) return null;
        Set<String> user = userWords();
        int maxD = lower.length() <= 4 ? 1 : 2;
        String best = null;
        int bestD = 99, bestScore = -1;
        Map<String, Integer> rk = ranks.get(lang);
        Map<String, Integer> lm = learnedMap(lang);
        for (String w : candidatesPool(lang, user)) {
            if (Math.abs(w.length() - lower.length()) > maxD) continue;
            Integer lc = lm.get(w);
            if (!rk.containsKey(w) && !user.contains(w) && (lc == null || lc < 2)) continue;
            int d = distance(lower, w, maxD);
            if (d > maxD) continue;
            if (w.charAt(0) != lower.charAt(0)) d += 1;
            if (d > maxD) continue;
            int s = score(w, lang, user);
            if (d < bestD || (d == bestD && s > bestScore)) {
                best = w; bestD = d; bestScore = s;
            }
        }
        return best == null ? null : applyCase(best, typed);
    }

    /** Glide typing: key path letters → likely words. */
    public List<String> glide(String seq, String lang, int n) {
        List<String> out = new ArrayList<>();
        if (seq.length() < 2) return out;
        char first = seq.charAt(0), last = seq.charAt(seq.length() - 1);
        Set<String> user = userWords();
        List<String> found = new ArrayList<>();
        final Map<String, Integer> sc = new HashMap<>();
        for (String w : candidatesPool(lang, user)) {
            if (w.length() < 2 || w.charAt(0) != first || w.charAt(w.length() - 1) != last) continue;
            String col = collapse(w);
            if (!isSubsequence(col, seq)) continue;
            found.add(w);
            sc.put(w, col.length() * 450 + score(w, lang, user) - Math.max(0, seq.length() - col.length() * 3) * 20);
        }
        Collections.sort(found, (a, b) -> sc.get(b) - sc.get(a));
        for (String w : found) {
            out.add(w);
            if (out.size() >= n) break;
        }
        return out;
    }

    public List<String> starters(String lang) {
        List<String> l = new ArrayList<>();
        switch (lang) {
            case "hi": Collections.addAll(l, "मैं", "आप", "क्या"); break;
            case "mr": Collections.addAll(l, "मी", "तुम्ही", "काय"); break;
            case "bho": Collections.addAll(l, "हम", "रउआ", "का"); break;
            default: Collections.addAll(l, "I", "The", "How");
        }
        return l;
    }

    public void learn(String word, String lang, int amount) {
        if (word == null) return;
        String lw = word.toLowerCase(Locale.ROOT).trim();
        if (lw.length() < 2 || lw.length() > 30) return;
        for (int i = 0; i < lw.length(); i++) {
            char ch = lw.charAt(i);
            if (Character.isDigit(ch) || Character.isWhitespace(ch)) return;
        }
        Map<String, Integer> m = learnedMap(lang);
        Integer c = m.get(lw);
        int v = (c == null ? 0 : c) + amount;
        m.put(lw, v);
        Prefs.data(ctx).edit().putInt("l_" + lang + "_" + lw, v).apply();
    }

    public synchronized void clearLearned() {
        SharedPreferences.Editor ed = Prefs.data(ctx).edit();
        for (String k : Prefs.data(ctx).getAll().keySet()) if (k.startsWith("l_")) ed.remove(k);
        ed.apply();
        learned.clear();
    }

    // ---- helpers ----
    static String applyCase(String w, String typed) {
        if (typed.isEmpty() || w.isEmpty()) return w;
        if (typed.length() > 1 && typed.equals(typed.toUpperCase(Locale.ROOT)) && !typed.equals(typed.toLowerCase(Locale.ROOT))) {
            return w.toUpperCase(Locale.ROOT);
        }
        if (Character.isUpperCase(typed.charAt(0))) return capitalize(w);
        return w;
    }

    static String capitalize(String w) {
        if (w.isEmpty()) return w;
        return w.substring(0, 1).toUpperCase(Locale.ROOT) + w.substring(1);
    }

    private static String collapse(String w) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length(); i++) {
            char ch = w.charAt(i);
            if (sb.length() == 0 || sb.charAt(sb.length() - 1) != ch) sb.append(ch);
        }
        return sb.toString();
    }

    private static boolean isSubsequence(String small, String big) {
        int j = 0;
        for (int i = 0; i < big.length() && j < small.length(); i++) {
            if (big.charAt(i) == small.charAt(j)) j++;
        }
        return j == small.length();
    }

    /** Damerau-Levenshtein (optimal string alignment) with early exit. */
    static int distance(String a, String b, int max) {
        int n = a.length(), m = b.length();
        int[][] d = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++) d[i][0] = i;
        for (int j = 0; j <= m; j++) d[0][j] = j;
        for (int i = 1; i <= n; i++) {
            int rowMin = Integer.MAX_VALUE;
            for (int j = 1; j <= m; j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                int v = Math.min(Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1), d[i - 1][j - 1] + cost);
                if (i > 1 && j > 1 && a.charAt(i - 1) == b.charAt(j - 2) && a.charAt(i - 2) == b.charAt(j - 1)) {
                    v = Math.min(v, d[i - 2][j - 2] + 1);
                }
                d[i][j] = v;
                rowMin = Math.min(rowMin, v);
            }
            if (rowMin > max) return max + 1;
        }
        return d[n][m];
    }
}
