package com.typemate.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Draws a small live preview of a keyboard theme. */
public class ThemePreviewView extends View {
    private KeyboardTheme theme;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path clip = new Path();
    private final float dp;
    private boolean labels = true;

    public ThemePreviewView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        tp.setTextAlign(Paint.Align.CENTER);
    }

    public void setTheme(KeyboardTheme t) { theme = t; invalidate(); }
    public void setLabels(boolean b) { labels = b; }

    @Override protected void onDraw(Canvas c) {
        if (theme == null) return;
        float w = getWidth(), h = getHeight();
        clip.reset();
        clip.addRoundRect(new RectF(0, 0, w, h), 12 * dp, 12 * dp, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        p.setShader(new LinearGradient(0, 0, 0, h, theme.bgTop, theme.bgBottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
        float tb = h * 0.15f;
        if (theme.toolbar != 0) {
            p.setColor(theme.toolbar);
            c.drawRect(0, 0, w, tb, p);
        }
        p.setColor(theme.toolbarIcon);
        for (int i = 0; i < 5; i++) {
            c.drawCircle(w * (0.1f + i * 0.2f), tb / 2, Math.max(2 * dp, tb * 0.14f), p);
        }
        float top = tb + 2 * dp;
        int rowsN = 5;
        float rh = (h - top - 2 * dp) / rowsN;
        float gap = Math.max(1.5f * dp, w / 160f);
        float rad = Math.min(theme.radius * dp * 0.6f, rh * 0.3f);
        String[] rowsLbl = {"1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm", ""};
        for (int row = 0; row < rowsN; row++) {
            float y = top + row * rh;
            float[] weights;
            int[] kinds; // 0 key, 1 func, 2 action, 3 number
            switch (row) {
                case 0: weights = rep(10, 1f); kinds = repI(10, 3); break;
                case 1: weights = rep(10, 1f); kinds = repI(10, 0); break;
                case 2: weights = new float[]{0.5f, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.5f}; kinds = new int[]{-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1}; break;
                case 3: weights = new float[]{1.5f, 1, 1, 1, 1, 1, 1, 1, 1.5f}; kinds = new int[]{1, 0, 0, 0, 0, 0, 0, 0, 1}; break;
                default: weights = new float[]{1.5f, 1, 1, 4, 1, 1.5f}; kinds = new int[]{1, 1, 1, 0, 1, 2};
            }
            float total = 0;
            for (float f : weights) total += f;
            float x = 0;
            int li = 0;
            for (int k = 0; k < weights.length; k++) {
                float kw = w * weights[k] / total;
                if (kinds[k] >= 0) {
                    r.set(x + gap, y + gap, x + kw - gap, y + rh - gap);
                    int bg, fg;
                    switch (kinds[k]) {
                        case 1: bg = theme.func; fg = theme.funcText; break;
                        case 2: bg = theme.action; fg = theme.actionText; break;
                        case 3: bg = theme.numKey; fg = theme.numText; break;
                        default: bg = theme.key; fg = theme.keyText;
                    }
                    p.setColor(bg);
                    c.drawRoundRect(r, rad, rad, p);
                    if (theme.border != 0) {
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(Math.max(1, dp / 2));
                        p.setColor(theme.border);
                        c.drawRoundRect(r, rad, rad, p);
                        p.setStyle(Paint.Style.FILL);
                    }
                    String lbl = rowsLbl[row];
                    if (labels && kinds[k] != 1 && kinds[k] != 2 && li < lbl.length()) {
                        tp.setColor(fg);
                        tp.setTextSize(rh * 0.5f);
                        Paint.FontMetrics fm = tp.getFontMetrics();
                        c.drawText(String.valueOf(lbl.charAt(li)), r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2, tp);
                    }
                    if (kinds[k] == 0 || kinds[k] == 3) li++;
                }
                x += kw;
            }
        }
        c.restore();
    }

    private static float[] rep(int n, float v) {
        float[] a = new float[n];
        for (int i = 0; i < n; i++) a[i] = v;
        return a;
    }

    private static int[] repI(int n, int v) {
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = v;
        return a;
    }
}
