package com.typemate.keyboard;

import android.content.Context;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** Clipboard history saved on the phone only. */
public final class ClipHistory {
    private static final String KEY = "clips";

    private ClipHistory() {}

    public static List<String> get(Context c) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.data(c).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (Exception ignored) {
        }
        return out;
    }

    private static void save(Context c, List<String> l) {
        JSONArray a = new JSONArray();
        for (String s : l) a.put(s);
        Prefs.data(c).edit().putString(KEY, a.toString()).apply();
    }

    public static void add(Context c, String text) {
        if (text == null) return;
        String t = text.length() > 5000 ? text.substring(0, 5000) : text;
        if (t.trim().isEmpty()) return;
        List<String> l = get(c);
        l.remove(t);
        l.add(0, t);
        int max = Math.max(5, Prefs.i(c, Prefs.CLIP_MAX));
        while (l.size() > max) l.remove(l.size() - 1);
        save(c, l);
    }

    public static void remove(Context c, String text) {
        List<String> l = get(c);
        l.remove(text);
        save(c, l);
    }

    public static void clear(Context c) {
        save(c, new ArrayList<>());
    }
}
