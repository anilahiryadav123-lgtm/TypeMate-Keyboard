package com.typemate.keyboard;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.io.File;
import java.io.FileOutputStream;

/** Built-in text + emoji stickers drawn on the phone (no internet needed). */
public final class StickerMaker {
    // emoji, caption, colour
    public static final String[][] STICKERS = {
            {"🙏", "Namaste", "FF6D00"}, {"🌞", "Good Morning", "FFB300"}, {"🌙", "Good Night", "3949AB"},
            {"❤️", "Love You", "E53935"}, {"😂", "Haha", "FDD835"}, {"👍", "OK", "43A047"},
            {"🎂", "Happy Birthday", "D81B60"}, {"🙏", "Thank You", "00897B"}, {"😎", "Cool", "1E88E5"},
            {"🥳", "Party Time", "8E24AA"}, {"😢", "Miss You", "5C6BC0"}, {"🤝", "Welcome", "00ACC1"},
            {"🔥", "Super", "F4511E"}, {"🎉", "Congrats", "7CB342"}, {"☕", "Chai Time", "6D4C41"},
            {"😴", "Sleepy", "546E7A"}, {"🤔", "Hmm...", "FB8C00"}, {"😡", "Gussa", "C62828"},
            {"🪔", "Happy Diwali", "FF8F00"}, {"🇮🇳", "Jai Hind", "FF9933"}, {"😍", "Wow", "EC407A"},
            {"🙌", "Shabash", "26A69A"}, {"📞", "Call Me", "039BE5"}, {"👋", "Bye Bye", "7E57C2"},
            {"🌹", "Shubh Prabhat", "E91E63"}, {"🙂", "Kaise Ho?", "0097A7"}, {"💯", "Done", "2E7D32"},
            {"🤣", "LOL", "F9A825"}
    };

    private StickerMaker() {}

    public static Bitmap render(int index, int size) {
        String[] s = STICKERS[index];
        int color = 0xFF000000 | Integer.parseInt(s[2], 16);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float u = size / 100f;
        // emoji
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(52 * u);
        c.drawText(s[0], size / 2f, 58 * u, p);
        // caption pill
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tp.setTextAlign(Paint.Align.CENTER);
        float ts = 15 * u;
        tp.setTextSize(ts);
        while (tp.measureText(s[1]) > 88 * u && ts > 8 * u) {
            ts -= u;
            tp.setTextSize(ts);
        }
        float tw = tp.measureText(s[1]);
        RectF pill = new RectF(size / 2f - tw / 2 - 6 * u, 68 * u, size / 2f + tw / 2 + 6 * u, 68 * u + ts + 10 * u);
        p.setColor(0xFFFFFFFF);
        c.drawRoundRect(new RectF(pill.left - 2 * u, pill.top - 2 * u, pill.right + 2 * u, pill.bottom + 2 * u), 14 * u, 14 * u, p);
        p.setColor(color);
        c.drawRoundRect(pill, 12 * u, 12 * u, p);
        tp.setColor(0xFFFFFFFF);
        Paint.FontMetrics fm = tp.getFontMetrics();
        c.drawText(s[1], pill.centerX(), pill.centerY() - (fm.ascent + fm.descent) / 2, tp);
        return b;
    }

    public static File save(Context ctx, int index) throws Exception {
        File f = new File(StickerProvider.dir(ctx), "sticker_" + index + ".png");
        Bitmap b = render(index, 512);
        try (FileOutputStream out = new FileOutputStream(f)) {
            b.compress(Bitmap.CompressFormat.PNG, 100, out);
        }
        return f;
    }
}
