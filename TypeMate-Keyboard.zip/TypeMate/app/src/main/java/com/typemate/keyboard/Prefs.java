package com.typemate.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All keyboard settings in one place. */
public final class Prefs {
    public static final String THEME = "theme";
    public static final String LANGS = "langs";
    public static final String LANG_INDEX = "lang_index";
    public static final String NUMBER_ROW = "number_row";
    public static final String KEY_BORDERS = "key_borders";
    public static final String KEY_POPUP = "key_popup";
    public static final String LONG_DELAY = "long_delay";
    public static final String HEIGHT = "height";
    public static final String TEXT_SIZE = "text_size";
    public static final String BOLD = "bold";
    public static final String ONE_HANDED = "one_handed";
    public static final String SOUND = "sound";
    public static final String SOUND_VOL = "sound_vol";
    public static final String VIBRATE = "vibrate";
    public static final String VIB_MS = "vib_ms";
    public static final String SUGGEST = "suggest";
    public static final String AUTOCORRECT = "autocorrect";
    public static final String AUTOCAP = "autocap";
    public static final String DOUBLE_SPACE = "double_space";
    public static final String LEARN = "learn";
    public static final String GLIDE = "glide";
    public static final String GLIDE_TRAIL = "glide_trail";
    public static final String VOICE = "voice";
    public static final String VOICE_LANG = "voice_lang";
    public static final String CLIPBOARD = "clipboard";
    public static final String CLIP_MAX = "clip_max";
    public static final String GIPHY_KEY = "giphy_key";
    public static final String USER_WORDS = "user_words";
    public static final String EMOJI_KEY = "emoji_key";

    public static final String[] ALL_LANGS = {"en", "hi", "mr", "bho"};

    private static final Map<String, Object> DEF = new HashMap<>();
    static {
        DEF.put(THEME, "black_yellow");
        DEF.put(LANGS, "en,hi");
        DEF.put(LANG_INDEX, 0);
        DEF.put(NUMBER_ROW, true);
        DEF.put(KEY_BORDERS, false);
        DEF.put(KEY_POPUP, true);
        DEF.put(LONG_DELAY, 350);
        DEF.put(HEIGHT, 100);
        DEF.put(TEXT_SIZE, 100);
        DEF.put(BOLD, false);
        DEF.put(ONE_HANDED, "0");
        DEF.put(SOUND, false);
        DEF.put(SOUND_VOL, 50);
        DEF.put(VIBRATE, true);
        DEF.put(VIB_MS, 20);
        DEF.put(SUGGEST, true);
        DEF.put(AUTOCORRECT, true);
        DEF.put(AUTOCAP, true);
        DEF.put(DOUBLE_SPACE, true);
        DEF.put(LEARN, true);
        DEF.put(GLIDE, true);
        DEF.put(GLIDE_TRAIL, true);
        DEF.put(VOICE, true);
        DEF.put(VOICE_LANG, "auto");
        DEF.put(CLIPBOARD, true);
        DEF.put(CLIP_MAX, 30);
        DEF.put(GIPHY_KEY, "");
        DEF.put(EMOJI_KEY, true);
    }

    private Prefs() {}

    /** Settings (changing these rebuilds the keyboard). */
    public static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("typemate", Context.MODE_PRIVATE);
    }

    /** Fast-changing data: clipboard history, learned words, recent emojis. */
    public static SharedPreferences data(Context c) {
        return c.getSharedPreferences("typemate_data", Context.MODE_PRIVATE);
    }

    public static boolean b(Context c, String key) {
        Object d = DEF.get(key);
        return sp(c).getBoolean(key, d instanceof Boolean ? (Boolean) d : false);
    }

    public static int i(Context c, String key) {
        Object d = DEF.get(key);
        return sp(c).getInt(key, d instanceof Integer ? (Integer) d : 0);
    }

    public static String s(Context c, String key) {
        Object d = DEF.get(key);
        return sp(c).getString(key, d instanceof String ? (String) d : "");
    }

    public static boolean defBool(String key) {
        Object d = DEF.get(key);
        return d instanceof Boolean && (Boolean) d;
    }

    public static int defInt(String key) {
        Object d = DEF.get(key);
        return d instanceof Integer ? (Integer) d : 0;
    }

    public static String defStr(String key) {
        Object d = DEF.get(key);
        return d instanceof String ? (String) d : "";
    }

    public static List<String> langs(Context c) {
        List<String> out = new ArrayList<>();
        String v = s(c, LANGS);
        for (String l : ALL_LANGS) {
            if (("," + v + ",").contains("," + l + ",")) out.add(l);
        }
        if (out.isEmpty()) out.add("en");
        return out;
    }

    public static String langName(String code) {
        switch (code) {
            case "hi": return "हिन्दी";
            case "mr": return "मराठी";
            case "bho": return "भोजपुरी";
            default: return "English";
        }
    }

    public static String langEnglishName(String code) {
        switch (code) {
            case "hi": return "Hindi";
            case "mr": return "Marathi";
            case "bho": return "Bhojpuri";
            default: return "English (US)";
        }
    }
}
