package com.typemate.keyboard;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Home screen: setup steps + shortcuts + a box to try the keyboard. */
public class MainActivity extends Activity {
    private TextView step1, step2, step3;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout body = Ui.page(this, "TypeMate Keyboard", false);
        int p = Ui.dp(this, 20);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(p, p, p, p / 2);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        hero.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 120), Ui.dp(this, 120)));
        TextView name = new TextView(this);
        name.setText("TypeMate Keyboard");
        name.setTextSize(26);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextColor(0xFF0D1B5E);
        name.setPadding(0, Ui.dp(this, 10), 0, 0);
        hero.addView(name);
        TextView tag = new TextView(this);
        tag.setText("Fast • Beautiful • English, हिन्दी, मराठी, भोजपुरी");
        tag.setTextColor(Ui.SUB);
        tag.setTextSize(14);
        hero.addView(tag);
        body.addView(hero);

        Ui.section(this, body, "Setup");
        step1 = Ui.item(this, body, R.drawable.ic_keyboard, "1. Enable TypeMate", "", () ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        step2 = Ui.item(this, body, R.drawable.ic_done, "2. Select TypeMate", "", () -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        step3 = Ui.item(this, body, R.drawable.ic_mic, "3. Allow microphone", "", () ->
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 5));

        Ui.section(this, body, "Customize");
        Ui.item(this, body, R.drawable.ic_palette, "Theme Store", ThemeRegistry.all().size() + " keyboard themes with live preview", () ->
                startActivity(new Intent(this, ThemeStoreActivity.class)));
        Ui.item(this, body, R.drawable.ic_settings, "Settings", "Languages, preferences, typing, privacy", () ->
                startActivity(new Intent(this, SettingsActivity.class)));
        Ui.item(this, body, R.drawable.ic_globe, "Languages", "English, Hindi, Marathi, Bhojpuri", () ->
                startActivity(new Intent(this, SettingsDetailActivity.class).putExtra("page", "languages")));
        Ui.item(this, body, R.drawable.ic_book, "Personal dictionary", "Add your own words and names", () ->
                startActivity(new Intent(this, DictionaryActivity.class)));

        Ui.section(this, body, "Try it here");
        EditText try1 = new EditText(this);
        try1.setHint("Tap here and type…");
        try1.setMinLines(3);
        try1.setGravity(Gravity.TOP);
        try1.setBackground(Ui.card(this, 0xFFFFFFFF, 0xFFD0D4E4));
        try1.setPadding(p, p / 2, p, p / 2);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(p, Ui.dp(this, 6), p, 0);
        body.addView(try1, lp);

        TextView foot = new TextView(this);
        foot.setText("Made in India 🇮🇳  •  Developed by Anil Yadav");
        foot.setTextColor(Ui.SUB);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(this, 28), 0, 0);
        body.addView(foot);
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) refresh();
    }

    private void refresh() {
        boolean enabled = false;
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) {
            for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
                if (getPackageName().equals(i.getPackageName())) enabled = true;
            }
        }
        String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean selected = cur != null && cur.startsWith(getPackageName() + "/");
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        step1.setVisibility(android.view.View.VISIBLE);
        step1.setText(enabled ? "✅ Enabled" : "Tap to turn on TypeMate in keyboard settings");
        step2.setVisibility(android.view.View.VISIBLE);
        step2.setText(selected ? "✅ TypeMate is your keyboard" : "Tap to switch to TypeMate");
        step3.setVisibility(android.view.View.VISIBLE);
        step3.setText(mic ? "✅ Voice typing ready" : "Needed for voice typing");
    }
}
