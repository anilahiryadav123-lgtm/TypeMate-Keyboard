package com.typemate.keyboard;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Emoji categories loaded from assets/emoji.txt ("tabIcon|emoji emoji ..."). */
public final class EmojiData {
    private static Map<String, List<String>> cache;

    private EmojiData() {}

    public static synchronized Map<String, List<String>> load(Context c) {
        if (cache != null) return cache;
        Map<String, List<String>> m = new LinkedHashMap<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getAssets().open("emoji.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                int bar = line.indexOf('|');
                if (bar <= 0) continue;
                String tab = line.substring(0, bar).trim();
                List<String> l = new ArrayList<>();
                for (String e : line.substring(bar + 1).trim().split(" ")) if (!e.isEmpty()) l.add(e);
                m.put(tab, l);
            }
        } catch (Exception ignored) {
        }
        cache = m;
        return m;
    }

    public static List<String> recent(Context c) {
        List<String> l = new ArrayList<>();
        String s = Prefs.data(c).getString("emoji_recent", "");
        if (!s.isEmpty()) Collections.addAll(l, s.split(" "));
        return l;
    }

    public static void addRecent(Context c, String e) {
        List<String> l = recent(c);
        l.remove(e);
        l.add(0, e);
        while (l.size() > 40) l.remove(l.size() - 1);
        Prefs.data(c).edit().putString("emoji_recent", android.text.TextUtils.join(" ", l)).apply();
    }
}
