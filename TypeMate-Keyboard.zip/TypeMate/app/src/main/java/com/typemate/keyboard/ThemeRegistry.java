package com.typemate.keyboard;

import java.util.ArrayList;
import java.util.List;

/** 100+ built-in keyboard themes. */
public final class ThemeRegistry {
    private static List<KeyboardTheme> all;

    private ThemeRegistry() {}

    public static synchronized List<KeyboardTheme> all() {
        if (all == null) all = build();
        return all;
    }

    public static KeyboardTheme get(String id) {
        for (KeyboardTheme t : all()) if (t.id.equals(id)) return t;
        return all().get(0);
    }

    private static KeyboardTheme named(List<KeyboardTheme> l, String id, String name, String cat,
                                       int bg, int key, int keyText, int func, int funcText,
                                       int action, int actionText, int toolbar, int icon, int accent) {
        KeyboardTheme t = new KeyboardTheme(id, name, cat);
        t.bgTop = bg; t.bgBottom = bg;
        t.key = key; t.keyText = keyText;
        t.func = func; t.funcText = funcText;
        t.action = action; t.actionText = actionText;
        t.toolbar = toolbar; t.toolbarIcon = icon;
        t.accent = accent;
        l.add(t);
        return t;
    }

    private static void gradient(List<KeyboardTheme> l, String id, String name, int top, int bottom) {
        KeyboardTheme t = new KeyboardTheme(id, name, KeyboardTheme.GRADIENT);
        t.bgTop = top; t.bgBottom = bottom;
        boolean light = KeyboardTheme.lum(KeyboardTheme.mix(top, bottom, 0.5f)) > 0.62;
        if (light) {
            t.key = 0xB3FFFFFF; t.keyText = 0xFF222222;
            t.func = 0x66FFFFFF; t.funcText = 0xFF222222;
            t.action = KeyboardTheme.mix(bottom, 0xFF000000, 0.35f); t.actionText = 0xFFFFFFFF;
            t.toolbarIcon = 0xFF333333;
        } else {
            t.key = 0x38FFFFFF; t.keyText = 0xFFFFFFFF;
            t.func = 0x26000000; t.funcText = 0xFFFFFFFF;
            t.action = 0xFFFFFFFF; t.actionText = KeyboardTheme.mix(top, 0xFF000000, 0.2f);
            t.toolbarIcon = 0xFFFFFFFF;
        }
        t.toolbar = 0;
        t.accent = light ? KeyboardTheme.mix(top, 0xFF000000, 0.3f) : 0xFFFFFFFF;
        t.shadow = false;
        l.add(t.finish());
    }

    private static void hueLight(List<KeyboardTheme> l, String id, String name, int c) {
        KeyboardTheme t = new KeyboardTheme(id + "_light", name + " Light", KeyboardTheme.LIGHT);
        t.bgTop = t.bgBottom = KeyboardTheme.mix(c, 0xFFFFFFFF, 0.86f);
        t.key = 0xFFFFFFFF; t.keyText = 0xFF202124;
        t.func = KeyboardTheme.mix(c, 0xFFFFFFFF, 0.62f); t.funcText = 0xFF202124;
        t.action = c; t.actionText = KeyboardTheme.onColor(c);
        t.toolbar = t.bgTop; t.toolbarIcon = KeyboardTheme.mix(c, 0xFF000000, 0.35f);
        t.accent = c;
        l.add(t.finish());
    }

    private static void hueDark(List<KeyboardTheme> l, String id, String name, int c) {
        KeyboardTheme t = new KeyboardTheme(id + "_dark", name + " Dark", KeyboardTheme.DARK);
        t.bgTop = t.bgBottom = KeyboardTheme.mix(c, 0xFF000000, 0.86f);
        t.key = KeyboardTheme.mix(c, 0xFF000000, 0.68f); t.keyText = 0xFFFFFFFF;
        t.func = KeyboardTheme.mix(c, 0xFF000000, 0.78f); t.funcText = KeyboardTheme.mix(c, 0xFFFFFFFF, 0.6f);
        t.action = c; t.actionText = KeyboardTheme.onColor(c);
        t.toolbar = t.bgTop; t.toolbarIcon = KeyboardTheme.mix(c, 0xFFFFFFFF, 0.5f);
        t.accent = c;
        l.add(t.finish());
    }

    private static void hueVivid(List<KeyboardTheme> l, String id, String name, int c) {
        KeyboardTheme t = new KeyboardTheme(id + "_vivid", name + " Vivid", KeyboardTheme.COLORFUL);
        t.bgTop = t.bgBottom = KeyboardTheme.mix(c, 0xFF000000, 0.25f);
        t.key = KeyboardTheme.mix(c, 0xFFFFFFFF, 0.25f); t.keyText = KeyboardTheme.onColor(t.key);
        t.func = KeyboardTheme.mix(c, 0xFF000000, 0.45f); t.funcText = 0xFFFFFFFF;
        t.action = 0xFFFFFFFF; t.actionText = KeyboardTheme.mix(c, 0xFF000000, 0.3f);
        t.toolbar = t.bgTop; t.toolbarIcon = 0xFFFFFFFF;
        t.accent = 0xFFFFFFFF;
        l.add(t.finish());
    }

    private static List<KeyboardTheme> build() {
        List<KeyboardTheme> l = new ArrayList<>();
        final int W = 0xFFFFFFFF, B = 0xFF000000;

        KeyboardTheme t;
        t = named(l, "black_yellow", "Black & Yellow", KeyboardTheme.DARK, B, 0xFFF0E442, B, W, B, W, B, 0xFF141414, 0xFFBDBDBD, 0xFF1E88E5);
        t.numKey = 0xFFE8A202; t.numText = B; t.shimmer = true; t.finish();
        named(l, "white_blue", "White & Blue", KeyboardTheme.LIGHT, 0xFFEDEEF5, W, 0xFF1F1F1F, 0xFFDDE1F9, 0xFF1F1F1F, 0xFFDDE1F9, 0xFF1F1F1F, 0xFFEDEEF5, 0xFF1F1F1F, 0xFF0B57D0).finish();
        named(l, "dark_black", "Dark Black", KeyboardTheme.DARK, 0xFF1B1B1F, 0xFF3A3A40, W, 0xFF2A2A30, 0xFFE3E3E3, 0xFF8AB4F8, 0xFF0D1B2A, 0xFF1B1B1F, 0xFFC4C7C5, 0xFF8AB4F8).finish();
        named(l, "royal_blue", "Royal Blue", KeyboardTheme.DARK, 0xFF0D1B5E, 0xFF1E3A8A, W, 0xFF152C70, W, 0xFF3B82F6, W, 0xFF0B1650, 0xFFBFD3FF, 0xFF60A5FA).finish();
        named(l, "purple", "Purple", KeyboardTheme.DARK, 0xFF2A0F4A, 0xFF4B2A7B, W, 0xFF3A1C63, W, 0xFFA855F7, W, 0xFF220B3D, 0xFFD8B4FE, 0xFFC084FC).finish();
        t = named(l, "red_black", "Red & Black", KeyboardTheme.DARK, 0xFF0A0A0A, 0xFF1C1C1C, 0xFFFF3B3B, 0xFF2B0A0A, 0xFFFF5252, 0xFFE11D2A, W, B, 0xFFFF5252, 0xFFFF1744);
        t.border = 0xFF5A0F0F; t.finish();
        named(l, "green", "Green", KeyboardTheme.DARK, 0xFF0B3D1E, 0xFF146B34, W, 0xFF0F5228, W, 0xFF22C55E, 0xFF052E12, 0xFF08311A, 0xFFBBF7D0, 0xFF4ADE80).finish();
        named(l, "pink", "Pink", KeyboardTheme.LIGHT, 0xFFFFE4F1, W, 0xFF5B1237, 0xFFFFC2DF, 0xFF5B1237, 0xFFEC4899, W, 0xFFFFE4F1, 0xFFBE185D, 0xFFEC4899).finish();
        named(l, "orange", "Orange", KeyboardTheme.COLORFUL, 0xFF3B1F00, 0xFFFF9800, 0xFF1A0E00, 0xFFB86B00, W, W, 0xFFE65100, 0xFF2E1800, 0xFFFFB74D, 0xFFFF9800).finish();
        named(l, "sky_blue", "Sky Blue", KeyboardTheme.LIGHT, 0xFFD8F1FF, W, 0xFF0B3954, 0xFFA9DDF7, 0xFF0B3954, 0xFF0EA5E9, W, 0xFFD8F1FF, 0xFF0369A1, 0xFF0EA5E9).finish();
        t = named(l, "gold", "Gold", KeyboardTheme.DARK, 0xFF1A1405, 0xFF2B2210, 0xFFFFD54F, 0xFF3A2D0E, 0xFFFFD54F, 0xFFFFC107, 0xFF1A1405, 0xFF120E03, 0xFFFFD54F, 0xFFFFC107);
        t.border = 0xFF8D6E1F; t.finish();
        t = named(l, "amoled", "AMOLED Black", KeyboardTheme.DARK, B, B, W, B, 0xFFBDBDBD, 0xFF1A73E8, W, B, 0xFF9E9E9E, 0xFF1A73E8);
        t.border = 0xFF2E2E2E; t.shadow = false; t.finish();
        named(l, "classic_light", "Classic Light", KeyboardTheme.LIGHT, 0xFFE8EAED, W, 0xFF202124, 0xFFD2D5DB, 0xFF202124, 0xFF1A73E8, W, 0xFFE8EAED, 0xFF5F6368, 0xFF1A73E8).finish();
        named(l, "classic_dark", "Classic Dark", KeyboardTheme.DARK, 0xFF202124, 0xFF3C4043, W, 0xFF2D2E31, 0xFFE8EAED, 0xFF8AB4F8, 0xFF202124, 0xFF202124, 0xFF9AA0A6, 0xFF8AB4F8).finish();
        named(l, "black_white", "Black & White", KeyboardTheme.DARK, B, W, B, 0xFF9E9E9E, B, W, B, B, W, W).finish();
        t = named(l, "neon", "Neon Night", KeyboardTheme.DARK, 0xFF0A0A1A, 0xFF111133, 0xFF00FFC6, 0xFF0D0D26, 0xFFFF2BD6, 0xFF00FFC6, 0xFF0A0A1A, 0xFF0A0A1A, 0xFF00FFC6, 0xFFFF2BD6);
        t.border = 0xFF00BFA5; t.finish();
        named(l, "coffee", "Coffee", KeyboardTheme.DARK, 0xFF3E2723, 0xFF6D4C41, 0xFFFFF3E0, 0xFF4E342E, 0xFFFFE0B2, 0xFFD7A86E, 0xFF3E2723, 0xFF3E2723, 0xFFD7A86E, 0xFFD7A86E).finish();
        named(l, "mint_fresh", "Mint Fresh", KeyboardTheme.LIGHT, 0xFFDDF7EC, W, 0xFF0F3D2E, 0xFFB5EBD4, 0xFF0F3D2E, 0xFF10B981, W, 0xFFDDF7EC, 0xFF047857, 0xFF10B981).finish();
        named(l, "lavender_light", "Lavender", KeyboardTheme.LIGHT, 0xFFEDE7F6, W, 0xFF311B92, 0xFFD1C4E9, 0xFF311B92, 0xFF7E57C2, W, 0xFFEDE7F6, 0xFF5E35B1, 0xFF7E57C2).finish();
        named(l, "ocean_deep", "Ocean Deep", KeyboardTheme.DARK, 0xFF002B36, 0xFF073642, 0xFFEEE8D5, 0xFF00212B, 0xFF93A1A1, 0xFF2AA198, W, 0xFF002B36, 0xFF93A1A1, 0xFF2AA198).finish();
        named(l, "cream", "Cream Paper", KeyboardTheme.LIGHT, 0xFFF5ECD7, 0xFFFFFBF0, 0xFF3E2C1C, 0xFFE8D9B5, 0xFF3E2C1C, 0xFF8D6E63, W, 0xFFF5ECD7, 0xFF6D4C41, 0xFF8D6E63).finish();
        named(l, "blue_white", "Blue & White", KeyboardTheme.COLORFUL, 0xFF1565C0, W, 0xFF0D47A1, 0xFF0D47A1, W, 0xFFFFC107, 0xFF1F1F1F, 0xFF1565C0, W, 0xFFFFC107).finish();
        named(l, "yellow_black", "Yellow & Black", KeyboardTheme.COLORFUL, 0xFFFFD600, B, 0xFFFFD600, 0xFF333333, 0xFFFFD600, B, W, 0xFFFFD600, B, B).finish();
        named(l, "cherry", "Cherry Red", KeyboardTheme.COLORFUL, 0xFF8B0000, 0xFFC62828, W, 0xFF6A0000, W, W, 0xFF8B0000, 0xFF8B0000, 0xFFFFCDD2, W).finish();
        named(l, "forest", "Forest", KeyboardTheme.DARK, 0xFF1B2E1B, 0xFF2E4D2E, 0xFFE8F5E9, 0xFF233823, 0xFFA5D6A7, 0xFF66BB6A, B, 0xFF1B2E1B, 0xFFA5D6A7, 0xFF66BB6A).finish();

        // Gradient themes
        gradient(l, "tiranga", "Tiranga", 0xFFFF9933, 0xFF138808);
        gradient(l, "sunset", "Sunset", 0xFFFF512F, 0xFFDD2476);
        gradient(l, "ocean_grad", "Ocean Wave", 0xFF2193B0, 0xFF6DD5ED);
        gradient(l, "purple_love", "Purple Love", 0xFFCC2B5E, 0xFF753A88);
        gradient(l, "mango", "Mango", 0xFFFFE259, 0xFFFFA751);
        gradient(l, "aqua", "Aqua Marine", 0xFF13547A, 0xFF80D0C7);
        gradient(l, "northern", "Northern Lights", 0xFF43CEA2, 0xFF185A9D);
        gradient(l, "royal_night", "Royal Night", 0xFF141E30, 0xFF243B55);
        gradient(l, "fire", "Fire", 0xFFF12711, 0xFFF5AF19);
        gradient(l, "lavender_grad", "Lavender Dream", 0xFFC471F5, 0xFFFA71CD);
        gradient(l, "peach", "Peach", 0xFFFFDDE1, 0xFFEE9CA7);
        gradient(l, "cosmic", "Cosmic", 0xFF0F0C29, 0xFF302B63);
        gradient(l, "emerald", "Emerald Water", 0xFF348F50, 0xFF56B4D3);
        gradient(l, "berry", "Berry", 0xFF8E2DE2, 0xFF4A00E0);
        gradient(l, "sky_grad", "Morning Sky", 0xFFA1C4FD, 0xFFC2E9FB);
        gradient(l, "candy", "Candy", 0xFFFF9A9E, 0xFFFAD0C4);
        gradient(l, "midnight", "Midnight City", 0xFF232526, 0xFF414345);
        gradient(l, "rainbow_blue", "Blue Raspberry", 0xFF00B4DB, 0xFF0083B0);
        gradient(l, "lime_grad", "Lime Punch", 0xFFA8E063, 0xFF56AB2F);
        gradient(l, "rose_gold", "Rose Gold", 0xFFE8CBC0, 0xFF636FA4);
        gradient(l, "deep_sea", "Deep Sea", 0xFF000428, 0xFF004E92);
        gradient(l, "pink_grad", "Pink Flamingo", 0xFFF953C6, 0xFFB91D73);
        gradient(l, "golden_hour", "Golden Hour", 0xFFF7971E, 0xFFFFD200);
        gradient(l, "mint_grad", "Mint Breeze", 0xFFD4FC79, 0xFF96E6A1);

        String[][] hues = {
                {"red", "Red", "F44336"}, {"crimson", "Crimson", "C2185B"}, {"rose", "Rose", "E91E63"},
                {"magenta", "Magenta", "D500F9"}, {"violet", "Violet", "9C27B0"}, {"indigo", "Indigo", "3F51B5"},
                {"navy", "Navy", "1A237E"}, {"blue", "Blue", "1E88E5"}, {"azure", "Azure", "039BE5"},
                {"cyan", "Cyan", "00ACC1"}, {"teal", "Teal", "009688"}, {"mint", "Mint", "26A69A"},
                {"leaf", "Leaf Green", "43A047"}, {"lime", "Lime", "7CB342"}, {"olive", "Olive", "827717"},
                {"yellow", "Yellow", "FBC02D"}, {"amber", "Amber", "FFA000"}, {"tangerine", "Tangerine", "F57C00"},
                {"coral", "Coral", "FF7043"}, {"brown", "Brown", "6D4C41"}, {"slate", "Slate", "546E7A"},
                {"grey", "Grey", "757575"}, {"saffron", "Saffron", "FF9933"}, {"plum", "Plum", "8E24AA"}
        };
        for (String[] h : hues) {
            int c = 0xFF000000 | Integer.parseInt(h[2], 16);
            hueLight(l, h[0], h[1], c);
        }
        for (String[] h : hues) {
            int c = 0xFF000000 | Integer.parseInt(h[2], 16);
            hueDark(l, h[0], h[1], c);
        }
        for (int i = 0; i < hues.length; i += 2) {
            String[] h = hues[i];
            int c = 0xFF000000 | Integer.parseInt(h[2], 16);
            hueVivid(l, h[0], h[1], c);
        }
        // Extra colour themes (same Gboard-style keyboard)
        glossy(l, "ruby_gloss", "Ruby Gloss", 0xFF1A0508, 0xFFE11D48, 0xFFFFFFFF, 0xFF7F1028, 0xFFFFD166);
        glossy(l, "aurora_gloss", "Aurora Gloss", 0xFF061B2B, 0xFF14B8A6, 0xFF04201C, 0xFF0B4A55, 0xFF7CFFCB);
        glossy(l, "violet_gloss", "Violet Gloss", 0xFF140A2B, 0xFF8B5CF6, 0xFFFFFFFF, 0xFF4C1D95, 0xFFF0ABFC);
        glossy(l, "gold_gloss", "Gold Luxe", 0xFF0D0A02, 0xFFFFC21A, 0xFF2B1D00, 0xFF8A5A00, 0xFFFFF1A8);
        glossy(l, "ocean_gloss", "Ocean Glow", 0xFF02142B, 0xFF2196F3, 0xFFFFFFFF, 0xFF0B3C8A, 0xFF8FD3FF);
        glossy(l, "emerald_gloss", "Emerald Glow", 0xFF03170C, 0xFF22C55E, 0xFF032B12, 0xFF0B6B35, 0xFFB6FFCE);

        return l;
    }

    private static void glossy(List<KeyboardTheme> l, String id, String name, int bg, int key, int keyText,
                               int func, int accent) {
        KeyboardTheme t = new KeyboardTheme(id, name, KeyboardTheme.COLORFUL);
        t.bgTop = bg; t.bgBottom = KeyboardTheme.mix(bg, key, 0.18f);
        t.key = key; t.keyText = keyText;
        t.func = func; t.funcText = 0xFFFFFFFF;
        t.action = accent; t.actionText = 0xFF1A1A1A;
        t.numKey = KeyboardTheme.mix(key, 0xFF000000, 0.25f); t.numText = 0xFFFFFFFF;
        t.toolbar = KeyboardTheme.mix(bg, 0xFF000000, 0.35f); t.toolbarIcon = accent;
        t.accent = accent;
        l.add(t.finish());
    }
}
