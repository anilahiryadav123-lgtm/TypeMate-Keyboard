package com.typemate.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Draws the keys and handles touch: taps, long-press accents, delete repeat, space cursor swipe and glide typing. */
public class KeyboardView extends View {

    public interface Listener {
        void onKeyDown(Key k);
        void onKey(Key k, String text);
        void onLongAction(Key k);
        void onGlide(String seq);
        void onCursorMove(int steps);
    }

    private List<List<Key>> rows = new ArrayList<>();
    private KeyboardTheme theme;
    private Listener listener;
    private PreviewOverlay overlay;
    private final float dp;
    private final float u;        // 1 unit = 1/1080 of the screen's short side (keeps Gboard proportions on any phone)
    private final boolean land;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final Map<Integer, Drawable> icons = new HashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    public int shiftState;          // 0 off, 1 once, 2 caps lock
    public boolean caseSensitive = true;
    public String spaceLabel = "";
    public int enterIcon = R.drawable.ic_enter;
    public int heightPct = 100, textPct = 100, longPressMs = 350;
    public boolean bold, keyPopup = true, glideEnabled = true, glideTrail = true, borders;
    public boolean phonePad;

    private Key active, pressed;
    private int activeId = -1;
    private float downX, downY, lastSpaceX;
    private boolean consumed, altMode, gliding, spaceDrag;
    private String[] altList;
    private int altIndex;
    private final RectF altRect = new RectF();
    private float altCellW;
    private StringBuilder glideSeq;
    private Key lastGlideKey;
    private final Path trail = new Path();

    private final Runnable longPress = this::onLongPress;
    private final Runnable repeatDel = new Runnable() {
        @Override public void run() {
            if (active != null && active.code == Key.DEL && listener != null) {
                listener.onKeyDown(active);
                listener.onKey(active, null);
                handler.postDelayed(this, 55);
            }
        }
    };

    public KeyboardView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
        u = Math.min(dm.widthPixels, dm.heightPixels) / 1080f;
        land = dm.widthPixels > dm.heightPixels;
        stroke.setStyle(Paint.Style.STROKE);
        text.setTextAlign(Paint.Align.CENTER);
        trailPaint.setStyle(Paint.Style.STROKE);
        trailPaint.setStrokeCap(Paint.Cap.ROUND);
        trailPaint.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setListener(Listener l) { listener = l; }
    public void setOverlay(PreviewOverlay o) { overlay = o; }
    public void setTheme(KeyboardTheme t) { theme = t; updateShimmer(); invalidate(); }

    // ---- very light shimmer (only for themes with shimmer = true)
    private float shimmerPos = -1f;
    private android.animation.ValueAnimator shimmerAnim;
    private final Runnable shimmerLoop = new Runnable() {
        @Override public void run() {
            if (theme == null || !theme.shimmer || !isShown()) return;
            shimmerAnim = android.animation.ValueAnimator.ofFloat(-0.2f, 1.2f);
            shimmerAnim.setDuration(1500);
            shimmerAnim.addUpdateListener(a -> { shimmerPos = (float) a.getAnimatedValue(); invalidate(); });
            shimmerAnim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator an) {
                    shimmerPos = -1f;
                    invalidate();
                    handler.postDelayed(shimmerLoop, 3500);
                }
            });
            shimmerAnim.start();
        }
    };

    private void updateShimmer() {
        handler.removeCallbacks(shimmerLoop);
        if (shimmerAnim != null) { shimmerAnim.removeAllListeners(); shimmerAnim.cancel(); shimmerAnim = null; }
        shimmerPos = -1f;
        if (theme != null && theme.shimmer && isAttachedToWindow()) handler.postDelayed(shimmerLoop, 800);
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); updateShimmer(); }
    @Override protected void onDetachedFromWindow() { updateShimmer(); super.onDetachedFromWindow(); }
    @Override protected void onVisibilityChanged(View v, int vis) { super.onVisibilityChanged(v, vis); if (vis == VISIBLE) updateShimmer(); }
    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); }

    public void setRows(List<List<Key>> r) {
        rows = r;
        requestLayout();
        layoutKeys(getWidth());
        invalidate();
    }

    public void setShift(int s) {
        if (s != shiftState) { shiftState = s; invalidate(); }
    }

    private int rowHeight(List<Key> row) {
        float f = (land ? 0.8f : 1f) * heightPct / 100f;
        if (phonePad) {
            boolean last = !rows.isEmpty() && rows.get(rows.size() - 1) == row;
            return (int) ((last ? 138 : 166) * u * f);
        }
        return (int) (122 * u * f);
    }

    public int desiredHeight() {
        int h = (int) (8 * u);
        for (List<Key> r : rows) h += rowHeight(r);
        return h;
    }

    /** Height of a full letters page with number row; used for emoji/clipboard panels. */
    public static int panelHeight(Context c, int heightPct, boolean numberRow) {
        android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
        float u = Math.min(dm.widthPixels, dm.heightPixels) / 1080f;
        float f = (dm.widthPixels > dm.heightPixels ? 0.8f : 1f) * heightPct / 100f;
        return (int) ((8 + 122 * (numberRow ? 5 : 4)) * u * f);
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), desiredHeight());
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        layoutKeys(w);
    }

    private void layoutKeys(int w) {
        if (w <= 0) return;
        float y = 4 * u;
        float[] rowTop = new float[rows.size() + 1];
        int ri = 0;
        for (List<Key> row : rows) {
            rowTop[ri] = y;
            float total = 0;
            for (Key k : row) total += k.weight;
            float x = 0;
            int rh = rowHeight(row);
            for (Key k : row) {
                float kw = w * k.weight / total;
                k.rect.set(x, y, x + kw, y + rh);
                x += kw;
            }
            y += rh;
            ri++;
        }
        rowTop[ri] = y;
        // tall tile of the number pad (spans the first three rows)
        if (phonePad && rows.size() >= 3 && !rows.get(0).isEmpty() && rows.get(0).get(0).sub != null) {
            Key t = rows.get(0).get(0);
            float top = rowTop[0], bottom = rowTop[3], q = (bottom - top) / t.sub.length;
            for (int i = 0; i < t.sub.length; i++) t.sub[i].rect.set(t.rect.left, top + q * i, t.rect.right, top + q * (i + 1));
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override protected void onDraw(Canvas c) {
        if (theme == null) return;
        for (List<Key> row : rows) for (Key k : row) drawKey(c, k);
        if (shimmerPos >= 0 && theme.shimmer && getWidth() > 0) drawShimmer(c);
        if (gliding && glideTrail) {
            trailPaint.setColor(KeyboardTheme.withAlpha(theme.accent, 200));
            trailPaint.setStrokeWidth(5 * dp);
            c.drawPath(trail, trailPaint);
        }
    }

    private void drawShimmer(Canvas c) {
        float w = getWidth(), h = getHeight();
        for (List<Key> row : rows) for (Key k : row) {
            if (k.code == Key.SPACER) continue;
            float t = (k.rect.centerX() + k.rect.centerY() * 0.6f) / (w + h * 0.6f);
            float d = Math.abs(t - shimmerPos);
            if (d > 0.13f) continue;
            int a = (int) (70 * (1f - d / 0.13f));   // very soft, max ~27% white
            float ix = 8 * u, iy = 10 * u;
            tmp.set(k.rect.left + ix, k.rect.top + iy, k.rect.right - ix, k.rect.bottom - iy);
            float rad = theme.radius * 2f * u;
            if (k.code == Key.ENTER || k.code == Key.SYM || k.code == Key.ABC) rad = Math.min(tmp.width(), tmp.height()) / 2f;
            fill.setColor(android.graphics.Color.argb(a, 255, 255, 255));
            c.drawRoundRect(tmp, rad, rad, fill);
        }
    }

    private void drawTile(Canvas c, Key t) {
        float ix = 8 * u, iy = 10 * u;
        float top = t.sub[0].rect.top, bottom = t.sub[t.sub.length - 1].rect.bottom;
        tmp.set(t.rect.left + ix, top + iy, t.rect.right - ix, bottom - iy);
        float rad = theme.radius * 2f * u;
        fill.setColor(theme.func);
        c.drawRoundRect(tmp, rad, rad, fill);
        for (Key s : t.sub) {
            if (s == pressed) {
                RectF r = new RectF(s.rect.left + ix, s.rect.top + (s == t.sub[0] ? iy : 0), s.rect.right - ix, s.rect.bottom - (s == t.sub[t.sub.length - 1] ? iy : 0));
                fill.setColor(KeyboardTheme.lum(theme.func) > 0.5 ? 0x26000000 : 0x40FFFFFF);
                c.drawRoundRect(r, rad, rad, fill);
            }
            text.setColor(theme.funcText);
            text.setTextSize(46 * u * textPct / 100f);
            text.setTypeface(Typeface.DEFAULT);
            Paint.FontMetrics fm = text.getFontMetrics();
            c.drawText(s.label, s.rect.centerX(), s.rect.centerY() - (fm.ascent + fm.descent) / 2, text);
        }
    }

    private void drawKey(Canvas c, Key k) {
        if (k.code == Key.SPACER) { if (k.sub != null) drawTile(c, k); return; }
        float ix = 8 * u, iy = 10 * u;
        tmp.set(k.rect.left + ix, k.rect.top + iy, k.rect.right - ix, k.rect.bottom - iy);
        int bg, fg;
        if (k.code == Key.ENTER) { bg = theme.action; fg = theme.actionText; }
        else if (k.numberRow) { bg = theme.numKey; fg = theme.numText; }
        else if ((k.isFunc() || k.styleFunc) && !k.plain) { bg = theme.func; fg = theme.funcText; }
        else { bg = theme.key; fg = theme.keyText; }
        if (k.code == Key.SHIFT && shiftState == 2) { bg = theme.accent; fg = KeyboardTheme.onColor(theme.accent); }
        float rad = theme.radius * 2f * u;
        if (k.code == Key.ENTER || k.code == Key.SYM || k.code == Key.ABC) rad = Math.min(tmp.width(), tmp.height()) / 2f;
        if (theme.shadow && android.graphics.Color.alpha(bg) > 200) {
            fill.setColor(0x30000000);
            c.drawRoundRect(tmp.left, tmp.top + 1.3f * dp, tmp.right, tmp.bottom + 1.3f * dp, rad, rad, fill);
        }
        fill.setColor(bg);
        c.drawRoundRect(tmp, rad, rad, fill);
        if (k == pressed) {
            fill.setColor(KeyboardTheme.lum(bg) > 0.5 ? 0x26000000 : 0x40FFFFFF);
            c.drawRoundRect(tmp, rad, rad, fill);
        }
        int border = theme.border != 0 ? theme.border : (borders ? KeyboardTheme.withAlpha(fg, 70) : 0);
        if (border != 0) {
            stroke.setColor(border);
            stroke.setStrokeWidth(dp);
            c.drawRoundRect(tmp, rad, rad, stroke);
        }
        int icon = iconFor(k);
        if (icon != 0) {
            drawIcon(c, icon, fg, tmp);
            return;
        }
        String label = labelFor(k);
        if (label == null || label.isEmpty()) return;
        float size;
        if (k.code == Key.SPACE) size = 31;
        else if (k.isFunc() || label.codePointCount(0, label.length()) > 1) size = 38;
        else if (k.numberRow) size = 56;
        else if (phonePad) size = 86;
        else size = 64;
        text.setColor(k.code == Key.SPACE ? KeyboardTheme.withAlpha(fg, 200) : fg);
        text.setTextSize(size * u * textPct / 100f);
        text.setTypeface(bold || (k.isFunc() && k.code != Key.SPACE) ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        Paint.FontMetrics fm = text.getFontMetrics();
        c.drawText(label, tmp.centerX(), tmp.centerY() - (fm.ascent + fm.descent) / 2, text);
        if (k.hint != null) {
            text.setTextSize(28 * u);
            text.setTypeface(Typeface.DEFAULT);
            text.setColor(KeyboardTheme.withAlpha(fg, 150));
            c.drawText(k.hint, tmp.right - 14 * u, tmp.top + 32 * u, text);
        }
    }

    private int iconFor(Key k) {
        switch (k.code) {
            case Key.SHIFT: return shiftState == 0 ? R.drawable.ic_shift : (shiftState == 1 ? R.drawable.ic_shift_on : R.drawable.ic_caps);
            case Key.DEL: return R.drawable.ic_backspace;
            case Key.ENTER: return enterIcon;
            case Key.EMOJI: return R.drawable.ic_emoji;
            case Key.LANG: return R.drawable.ic_globe;
            default: return 0;
        }
    }

    private void drawIcon(Canvas c, int res, int color, RectF r) {
        Drawable d = icons.get(res);
        if (d == null) {
            Drawable src = getContext().getDrawable(res);
            if (src == null) return;
            d = src.mutate();
            icons.put(res, d);
        }
        d.setTint(color);
        int s = (int) (Math.min(64 * u, r.height() * 0.7f));
        int cx = (int) r.centerX(), cy = (int) r.centerY();
        d.setBounds(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2);
        d.draw(c);
    }

    private String labelFor(Key k) {
        if (k.code == Key.SPACE) return spaceLabel;
        return k.code == Key.NORMAL && !k.numberRow ? casify(k.label) : k.label;
    }

    private String casify(String s) {
        if (s == null) return null;
        return caseSensitive && shiftState > 0 ? s.toUpperCase(Locale.ROOT) : s;
    }

    // ------------------------------------------------------------------ touch

    private Key keyAt(float x, float y) {
        if (rows.isEmpty()) return null;
        if (phonePad && !rows.get(0).isEmpty() && rows.get(0).get(0).sub != null) {
            for (Key sk : rows.get(0).get(0).sub) if (sk.rect.contains(x, y)) return sk;
        }
        List<Key> row = null;
        for (List<Key> r : rows) {
            if (r.isEmpty()) continue;
            RectF f = r.get(0).rect;
            if (y < f.bottom) { row = r; break; }
        }
        if (row == null) row = rows.get(rows.size() - 1);
        for (int i = 0; i < row.size(); i++) {
            Key k = row.get(i);
            if (x >= k.rect.left && x < k.rect.right || (i == row.size() - 1 && x >= k.rect.right) || (i == 0 && x < k.rect.left)) {
                if (k.code == Key.SPACER) {
                    if (i == 0 && row.size() > 1) return row.get(1);
                    if (i > 0) return row.get(i - 1);
                }
                return k;
            }
        }
        return null;
    }

    private boolean isGlideKey(Key k) {
        return glideEnabled && !phonePad && k != null && k.code == Key.NORMAL && !k.numberRow
                && k.out != null && !k.out.isEmpty() && Character.isLetter(k.out.codePointAt(0));
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int idx = e.getActionIndex();
                if (active != null) finishActive(true);
                startPointer(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (activeId < 0) break;
                int pi = e.findPointerIndex(activeId);
                if (pi < 0) break;
                handleMove(e.getX(pi), e.getY(pi));
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int pid = e.getPointerId(e.getActionIndex());
                if (pid == activeId) finishActive(true);
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                finishActive(false);
                break;
        }
        return true;
    }

    private void startPointer(int pid, float x, float y) {
        Key k = keyAt(x, y);
        if (k == null) return;
        active = k;
        pressed = k;
        activeId = pid;
        downX = x; downY = y; lastSpaceX = x;
        consumed = altMode = gliding = spaceDrag = false;
        glideSeq = null;
        if (listener != null) listener.onKeyDown(k);
        if (k.code == Key.DEL) {
            if (listener != null) listener.onKey(k, null);
            consumed = true;
            handler.postDelayed(repeatDel, 400);
        }
        if (k.alts != null || k.code == Key.SPACE || k.code == Key.LANG || k.code == Key.SHIFT || k.longAction) {
            handler.postDelayed(longPress, k.code == Key.SPACE ? Math.max(longPressMs, 500) : longPressMs);
        }
        if (isGlideKey(k)) {
            glideSeq = new StringBuilder(k.out.toLowerCase(Locale.ROOT));
            lastGlideKey = k;
            trail.reset();
            trail.moveTo(x, y);
        }
        showPreview(k);
        invalidate();
    }

    private void handleMove(float x, float y) {
        if (active == null) return;
        if (altMode) {
            int idx = (int) ((x - altRect.left) / altCellW);
            idx = Math.max(0, Math.min(altList.length - 1, idx));
            if (idx != altIndex) {
                altIndex = idx;
                if (overlay != null) overlay.setAltIndex(idx);
            }
            return;
        }
        if (active.code == Key.SPACE && !consumed) {
            if (!spaceDrag && Math.abs(x - downX) > 14 * dp) {
                spaceDrag = true;
                handler.removeCallbacks(longPress);
                lastSpaceX = x;
            }
            if (spaceDrag) {
                float step = 11 * dp;
                int steps = (int) ((x - lastSpaceX) / step);
                if (steps != 0 && listener != null) {
                    listener.onCursorMove(steps);
                    lastSpaceX += steps * step;
                }
            }
            return;
        }
        if (consumed) return;
        if (glideSeq != null) {
            if (!gliding) {
                float dx = x - downX, dy = y - downY;
                float th = active.rect.width() * 0.75f;
                Key k = keyAt(x, y);
                if (dx * dx + dy * dy > th * th && k != active && isGlideKey(k)) {
                    gliding = true;
                    handler.removeCallbacks(longPress);
                    pressed = null;
                    if (overlay != null) overlay.clear();
                }
            }
            if (gliding) {
                trail.lineTo(x, y);
                Key k = keyAt(x, y);
                if (isGlideKey(k) && k != lastGlideKey) {
                    glideSeq.append(k.out.toLowerCase(Locale.ROOT));
                    lastGlideKey = k;
                }
                invalidate();
                return;
            }
            return;
        }
        Key k = keyAt(x, y);
        if (k != null && k != active && k.code != Key.SPACER && k.code != Key.DEL) {
            handler.removeCallbacks(longPress);
            active = k;
            pressed = k;
            if (k.alts != null || k.longAction) handler.postDelayed(longPress, longPressMs);
            showPreview(k);
            invalidate();
        }
    }

    private void onLongPress() {
        Key k = active;
        if (k == null || gliding || spaceDrag || listener == null) return;
        if (k.code == Key.SPACE || k.code == Key.LANG || k.code == Key.SHIFT || (k.longAction && k.alts == null)) {
            consumed = true;
            if (overlay != null) overlay.clear();
            listener.onLongAction(k);
            return;
        }
        if (k.alts == null || k.alts.length == 0) return;
        altList = new String[k.alts.length];
        for (int i = 0; i < k.alts.length; i++) altList[i] = casify(k.alts[i]);
        int n = altList.length;
        float cell = Math.max(k.rect.width(), 34 * dp);
        if (cell * n > getWidth()) cell = getWidth() / (float) n;
        altCellW = cell;
        float h = Math.min(k.rect.height() * 0.95f, 54 * dp);
        float left = k.rect.centerX() - cell / 2;
        left = Math.max(0, Math.min(getWidth() - cell * n, left));
        altRect.set(left, k.rect.top - h - 2 * dp, left + cell * n, k.rect.top - 2 * dp);
        altIndex = 0;
        altMode = true;
        glideSeq = null;
        if (overlay != null) {
            int[] off = offset();
            RectF r = new RectF(altRect);
            r.offset(off[0], off[1]);
            overlay.showAlts(r, altList, 0, cell);
        }
        if (listener != null) listener.onKeyDown(k);
    }

    private void finishActive(boolean commit) {
        handler.removeCallbacks(longPress);
        handler.removeCallbacks(repeatDel);
        Key k = active;
        if (commit && k != null && listener != null) {
            if (altMode) {
                if (altList != null && altIndex >= 0 && altIndex < altList.length) listener.onKey(k, altList[altIndex]);
            } else if (gliding) {
                if (glideSeq != null && glideSeq.length() >= 2) listener.onGlide(glideSeq.toString());
            } else if (!consumed && !spaceDrag) {
                if (k.code == Key.SPACE) listener.onKey(k, " ");
                else if (k.code == Key.NORMAL) listener.onKey(k, casify(k.out));
                else listener.onKey(k, null);
            }
        }
        active = null;
        pressed = null;
        activeId = -1;
        altMode = gliding = spaceDrag = consumed = false;
        altList = null;
        glideSeq = null;
        trail.reset();
        if (overlay != null) overlay.clear();
        invalidate();
    }

    public void cancelTouch() {
        handler.removeCallbacks(longPress);
        handler.removeCallbacks(repeatDel);
        active = null;
        pressed = null;
        activeId = -1;
        altMode = gliding = spaceDrag = consumed = false;
        if (overlay != null) overlay.clear();
        invalidate();
    }

    private int[] offset() {
        int[] a = new int[2], b = new int[2];
        getLocationInWindow(a);
        if (overlay != null) overlay.getLocationInWindow(b);
        return new int[]{a[0] - b[0], a[1] - b[1]};
    }

    private void showPreview(Key k) {
        if (overlay == null) return;
        if (!keyPopup || k.code != Key.NORMAL) { overlay.clear(); return; }
        int[] off = offset();
        RectF r = new RectF(k.rect);
        r.offset(off[0], off[1]);
        overlay.showPreview(r, labelFor(k));
    }
}
