package com.typemate.keyboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Personal dictionary: words here are always suggested and never auto-corrected. */
public class DictionaryActivity extends Activity {

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    private Set<String> words() {
        Set<String> s = Prefs.sp(this).getStringSet(Prefs.USER_WORDS, null);
        return s == null ? new HashSet<>() : new HashSet<>(s);
    }

    private void build() {
        LinearLayout body = Ui.page(this, "Personal dictionary", true);
        int p = Ui.dp(this, 20);
        LinearLayout add = new LinearLayout(this);
        add.setGravity(Gravity.CENTER_VERTICAL);
        add.setPadding(p, p / 2, p, p / 2);
        final EditText input = new EditText(this);
        input.setHint("Add a word (name, shop, slang…)");
        input.setSingleLine(true);
        add.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView btn = Ui.button(this, "Add", Ui.BLUE, 0xFFFFFFFF);
        btn.setOnClickListener(v -> {
            String w = input.getText().toString().trim();
            if (w.isEmpty() || w.contains(" ")) {
                Toast.makeText(this, "Enter one word", Toast.LENGTH_SHORT).show();
                return;
            }
            Set<String> s = words();
            s.add(w);
            Prefs.sp(this).edit().putStringSet(Prefs.USER_WORDS, s).apply();
            build();
        });
        add.addView(btn);
        body.addView(add);
        List<String> list = new ArrayList<>(words());
        java.util.Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
        if (list.isEmpty()) Ui.note(this, body, "No words yet. Words you add here are suggested while typing and never auto-corrected.");
        for (final String w : list) {
            Ui.item(this, body, R.drawable.ic_book, w, "Tap to delete", () -> new AlertDialog.Builder(this)
                    .setMessage("Delete \"" + w + "\"?")
                    .setPositiveButton("Delete", (d, x) -> {
                        Set<String> s = words();
                        s.remove(w);
                        Prefs.sp(this).edit().putStringSet(Prefs.USER_WORDS, s).apply();
                        build();
                    })
                    .setNegativeButton("Cancel", null).show());
        }
    }
}
